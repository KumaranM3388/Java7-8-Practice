package workout;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SampleProgram {

	public static void main(String[] args) {
//		List<Integer> l1 = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
//		
//		Integer summ = l1.stream().filter(num -> num%2 ==0).collect(Collectors.summingInt(Integer::intValue));
//		System.out.println(summ);
//		
//		Integer minNo = l1.stream().min(Integer::compareTo).get();
//		System.out.println(minNo);
//		
//		Integer multiplication = l1.stream().reduce(1, (a,b) -> a+b);
//		System.out.println(multiplication);
		
		String s1 = ". This is sample Application";
//		String newStr=s1.replaceAll("<[^>]*>", ""); 
//	    // Or str.replaceAll("\\u2022|\\.","");u2022 is unicode value of bullet 
//	    System.out.println(newStr);
				
		s1 = s1.replaceAll("\\u2022(?=\\s\\d\\.\\s[A-z])",""); // this will remove the • if only the bulet have \\s\\d\\.\\s[A-z] patern after it.
		System.out.println(s1);
	}

}
