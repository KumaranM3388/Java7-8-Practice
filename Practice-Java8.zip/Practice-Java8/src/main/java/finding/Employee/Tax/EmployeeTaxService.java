package finding.Employee.Tax;

import java.util.Comparator;
import java.util.List;


public class EmployeeTaxService {

//	public static List<Employee> filterEmployeeTaxDetails()
//	{
//		return EmployeeDAO.employeeDetails().stream().filter(ctc -> ctc.empSalary < 500000).collect(Collectors.toList());
//	}
	
	public static void main(String[] args) {
		List<Employee> l1 = EmployeeDAO.employeeDetails();
		l1.stream().sorted(Comparator.comparing(Employee::getEmpName)).forEach(obj -> System.out.println(obj));
	}

}
