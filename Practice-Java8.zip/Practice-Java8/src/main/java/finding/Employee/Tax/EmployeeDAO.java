package finding.Employee.Tax;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

	public static List<Employee> employeeDetails()
	{
		List<Employee> emp = new ArrayList<>();
		emp.add(new Employee(007, "Kumaran", "IT", 1400000.0));
		emp.add(new Employee(503, "Sasi", "IT", 850000.0));
		emp.add(new Employee(103, "Kumar", "QA", 750000.0));
		emp.add(new Employee(2700, "Basha", "TESTING", 470000.0));
		emp.add(new Employee(1700, "Sathish", "DEVOPS", 1200000.0));
		emp.add(new Employee(1300, "Rajesh", "TESTING", 500000.0));
		emp.add(new Employee(2600, "Sajesh", "TESTING", 400000.0));
		return emp;
	}
}
