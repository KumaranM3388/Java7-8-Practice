package EvenAndOdd;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class EvenAndOddNumbers
{
    public static void main(String[] args) {
    	
        List<Integer> myList = Arrays.asList(2, 3, 4, 6, 11, 8, 9, 5, 7, 10, 12, 15, 18);
        myList.stream().filter(num -> num%2 != 0).forEach(System.out::println);
        
        System.out.println("--------------------------------------------------");
        
        int[] myList1 = {2, 3, 4, 6, 11, 8, 9, 5, 7, 10, 12, 15, 18};
        Arrays.stream(myList1).filter(num -> num%2 != 0).forEach(System.out::println);
        
        Map<Integer, String> m1 = new HashMap<>();
        m1.put(1, "a");
        m1.put(3, "b");
        m1.put(5, "c");
        m1.put(7, "d");
        m1.put(2, "e");
        m1.put(4, "f");
        m1.put(6, "g");
        m1.put(8, "h");
        
        m1.entrySet().stream().filter(k -> k.getKey()%2 == 0).forEach(obj -> System.out.println(obj));
        
    }
}
