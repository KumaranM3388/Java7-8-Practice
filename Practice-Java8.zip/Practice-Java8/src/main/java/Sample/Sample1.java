package Sample;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

import java8.MinAndMax.EmployeeList;

public class Sample1 {

	public static void main(String[] args) {
		List<Integer> l1 = Arrays.asList(1, 3, 4, 2, 5, 6, 5, 2, 1);	
		
		Map<Integer, Long> m1 = l1.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(m1);
		
		List<Integer> m2 = l1.stream().collect(Collectors.toList());
		System.out.println(m2);
		
		Set<Integer> s1 = new HashSet<Integer>();
		Set<Integer> s2 = l1.stream().filter(dup -> !s1.add(dup)).collect(Collectors.toSet());
		System.out.println(s2);
		
		
		List<EmployeeList> el1 = new ArrayList<>();
		el1.add(new EmployeeList(133, "C", 29, "Male", "Infrastructure", 2016, 18000));
		el1.add(new EmployeeList(111, "A", 32, "Female", "IT", 2015, 25000));
		el1.add(new EmployeeList(155, "E", 27, "Female", "HR", 2018, 22700));
		el1.add(new EmployeeList(122, "B", 25, "Male", "IT", 2021, 13500));		
		el1.add(new EmployeeList(144, "D", 30, "Male", "IT", 2017, 32500));		
		el1.add(new EmployeeList(155, "F", 27, "Female", "HR", 2018, 25000));
		
		// Filtering AGE
		el1.stream().filter(age -> age.getAge() >= 30 && age.getAge() <= 32).map(EmployeeList::getName).forEach(System.out::println);
		
		// Each departement filtering highest salary
		Map<String, Optional<EmployeeList>> basedOnDeptHighSalary = el1.stream().collect(Collectors.groupingBy(EmployeeList::getDepartment, Collectors.maxBy(Comparator.comparingInt(EmployeeList::getSalary))));
		basedOnDeptHighSalary.entrySet().forEach(System.out::println);
		
		// Highest Salary
		Optional<EmployeeList> highestSalary = el1.stream().collect(Collectors.maxBy((Comparator.comparingInt(EmployeeList::getSalary))));
		System.out.println("Employee Max Salary -------->"+ highestSalary);

		// Only Employee Name
		List<String> onlyEmployeeName = el1.stream().map(EmployeeList::getName).sorted(Comparator.reverseOrder()).collect(Collectors.toList());
		System.out.println("Only Employee Name : " + onlyEmployeeName);
	}

}
