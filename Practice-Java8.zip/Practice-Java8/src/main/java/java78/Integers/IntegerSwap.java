package java78.Integers;

public class IntegerSwap {

	public static void main(String[] args) {
		
		int x = 5;
		int y = 10;
		
		int temp;
		
		temp = x;
		x = y;
		y = temp;
		
		System.out.println(x + " : " + y);
	}

}
