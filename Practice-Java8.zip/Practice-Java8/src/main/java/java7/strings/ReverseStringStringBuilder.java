package java7.strings;

public class ReverseStringStringBuilder {

	public static void main(String[] args) {
		String s1 = "Kumaran";
		
		StringBuilder strBuild = new StringBuilder();
		strBuild.append(s1);
		strBuild.reverse();
		System.out.println(strBuild);
	}

}
