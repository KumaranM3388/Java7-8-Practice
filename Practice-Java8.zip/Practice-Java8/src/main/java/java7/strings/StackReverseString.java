package java7.strings;

import java.util.Stack;

public class StackReverseString {

	public static String reverseString(String s1)
	{
		Stack<Character> stak1 = new Stack<>();
		char[] ch = s1.toCharArray();
		for(char c : ch)
		{
			stak1.push(c);
		}
		
		for(int i=0;i<s1.length();i++)
		{
			ch[i] = stak1.pop();
		}
		
		return new String(ch);
	}
	
	
	public static void main(String[] args) {
		String rev = "kumaran";
		rev = reverseString(rev);
		System.out.println(rev);
	}

}
