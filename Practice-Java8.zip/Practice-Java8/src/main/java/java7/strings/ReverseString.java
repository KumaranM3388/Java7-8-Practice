package java7.strings;

public class ReverseString {

	public static void main(String[] args) {
		String s1 = "Kumaran";
		
		String empt = "";
		char ch;
		
		for(int i=0;i<s1.length();i++)
		{
			ch = s1.charAt(i); //extracts each character
			empt = ch+empt; //adds each character in front of the existing string
		}
		System.out.println(empt);
	}

}
