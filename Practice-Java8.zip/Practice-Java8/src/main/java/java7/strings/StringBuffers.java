package java7.strings;

public class StringBuffers {

	public static void main(String[] args) 
	{
	StringBuffer sb = new StringBuffer(" Kumaran");
	//sb.reverse();
//	System.out.println(sb.capacity());
//	System.out.println(sb.length());
	
	sb.append(" Murugan");
	sb.insert(0, "M");
	//sb.deleteCharAt(7);
	System.out.println(sb);
	}

}
