package java7.strings;

public class StringsEvenOdd {

	public static void main(String[] args) {
		String s1 = "Hai Kumaran i am coming from java";
		for(String s2 : s1.split(" "))
		{
			if(s2.length() %2 == 0)
			{
				System.out.println(s2);
			}
		}
	}

}
