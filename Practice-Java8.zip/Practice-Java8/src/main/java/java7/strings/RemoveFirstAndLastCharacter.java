package java7.strings;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class RemoveFirstAndLastCharacter {

	public static void main(String[] args) {		
		
		String s1 = "KumaranM";
		System.out.println(s1.replaceFirst("K", ""));
		
		s1 = s1.substring(1, s1.length() -1);
		System.out.println(s1);
		
		String s2 = "Kumaran";
		Map<String, Long> strCount = Arrays.asList(s2.split("")).stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(strCount);
		
		Map<String, Long> strSpecificCharacterCount = Arrays.asList(s2.split("")).stream().filter(rem -> "a".equals(rem)).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(strSpecificCharacterCount);
	}

}
