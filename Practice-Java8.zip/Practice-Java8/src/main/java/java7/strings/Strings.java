package java7.strings;

public class Strings {

	public static void main(String[] args) 
	{
	   String s1 = new String("Kumaran");
	   System.out.println(s1.concat(" Murugan"));
	   
	   String s2 = "Kumaran";
	   System.out.println(s2.concat(" Murugan"));
	   
	   String name = " Kumaran";
	   name = name + " Murugan";
	   System.out.println("Hai" + name);
	   
	   String a = "SpringBoot";
       String b = "SpringBoot";
       String c =  new String("SpringBoot");
       
       System.out.println(a==c);
       System.out.println(b==c);
       System.out.println(a==b);
       
       if(a==c)
       {
           System.out.println("a and c are equal");
       }
       if(b==c)
       {
           System.out.println("b and c are equal");
       } 
       if(a==b)
       {
           System.out.println("a and b are equal");
       }
	}

}
