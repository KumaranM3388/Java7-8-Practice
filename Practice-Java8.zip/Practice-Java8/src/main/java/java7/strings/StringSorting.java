package java7.strings;

public class StringSorting {

	public static void main(String[] args) {
		String sorti = "Kumaranm";
		
	}

}
