package java7.strings;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class StringJoining {

	public static void main(String[] args) {
		List<String> strLst = Arrays.asList("C","A","D","B","E");
		
		String joiningWords = strLst.stream().sorted(Collections.reverseOrder()).collect(Collectors.joining()); // collect(Collectors.joining(","))
		System.out.println(joiningWords);
			
	}

}
