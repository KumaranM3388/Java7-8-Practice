package java7.strings;

import java.util.Arrays;
import java.util.List;

public class RemovingSpeceficCharacter {

	public static void main(String[] args) {
		List<String> strLst = Arrays.asList("C","A","D","B","E");
		
		// Removing specefic characters
		List<String> specificRemove = strLst.stream().sorted().filter(remove -> !"A".equals(remove)).toList();
	    System.out.println(specificRemove);
	}

}
