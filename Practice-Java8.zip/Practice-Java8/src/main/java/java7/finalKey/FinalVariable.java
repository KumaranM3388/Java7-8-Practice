package java7.finalKey;

public class FinalVariable {

	public static void main(String[] args) {
		int num = 10;
		
		// Final Variable
		//final int num = 10;
		
		num = 15;
		System.out.println(num);
	}

}
