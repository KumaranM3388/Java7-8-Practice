package java7.finalKey;

public class FinalMethodA 
{
  public final void show()
  {
	  System.out.println("Kumaran");
  }
}
