package java7.finalKey;

// Using Final keyword we can create - Variable, Method, Class.
// final public class FinalMethodA
// No one can override the same method using final keyword.
// Using final keyword with a class to stop inheretence.

public class FinalMethod 
{
public static void main(String args[])
{
	FinalMethodB finalMtdB = new FinalMethodB();
	finalMtdB.show();
	finalMtdB.add(5, 5);
}
}
