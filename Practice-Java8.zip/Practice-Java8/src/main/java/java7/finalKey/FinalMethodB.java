package java7.finalKey;

public class FinalMethodB extends FinalMethodA
{
	public void add(int n1, int n2)
	  {
		  System.out.println(n1 + n2);
	  }
	
	// No one can override the same method using final keyword.
	
//	public void show()
//	  {
//		  System.out.println("Samvritha");
//	  }
}
