package java7.encapsulation;

public class Encapsulations 
{
  public static void main(String args[])
  {
	  Human human = new Human();
	  human.setAge(30);
	  human.setName("Kumaran");
	  human.setHomeTown("Dharmapuri");
	  
	  System.out.println(human.getAge() + human.getName() + human.getHomeTown());
  }
}
