package java7.encapsulation;

public class Human 
{
  private int age;
  private String name;
  private String homeTown;
  
  
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}

public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}

public String getHomeTown() {
	return homeTown;
}
public void setHomeTown(String homeTown) {
	this.homeTown = homeTown;
}
  
 
}
