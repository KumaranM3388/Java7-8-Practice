package java7.statickey;

// The static keyword is a non-access modifier used for methods and attributes.
// Static methods/attributes can be accessed without creating an object of a class.
// We can apply static keyword with variables, methods, blocks and nested classes(inner class - class that is declared inside the class or interface).
// The static variable can be used to refer to the common property of all objects.
// The static block is used to initialize a static variable.

// Non static variable we can't use inside the static method.

public class StaticKeyWord {

	public static void main(String[] args) 
	{
	  ITDepartment itDept = new ITDepartment();
	  itDept.development = "Java";
	  itDept.testing = "Selenium";
	  itDept.dataBase = "Oracle";
	  itDept.devops = "Cloud";
	  
	  
	  ITDepartment itDept1 = new ITDepartment();
	  itDept1.development = "Spring Boot";
	  itDept1.testing = "Automatation";
	  itDept1.dataBase = "MySQL";
	  itDept1.devops = "Security";
	  
	  itDept1.development = "Backemd Developer";
	  
	  itDept.show();
	  itDept1.show();
	  ITDepartment.show1();
	}

}
