package java7.statickey;

public class ITDepartment 
{
   //static String development;
   String development;
   String testing;
   String dataBase;
   String devops;
   
   // Instance method
   public void show()
   {
	   System.out.println(development + " : " +testing + " : "+dataBase+ " : "+devops);
   }
   
   // Static method
   public static void show1()
   {
	   System.out.println("Hi i am static method :");
   }
}
