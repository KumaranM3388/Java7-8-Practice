package java7.abstractkeywork;

// Abstract class we can extend only one class.
// We con't create any object of abstract class.
// If we have abstract method only in the abstract class.
// Abstract class can allow abstract method and non-abstract method.
// We can create multiple abstract method.
// All the abstract method should be implement.
// Abstract class can having normal methods also.

public class AbstractKeyWord {

	public static void main(String[] args) {
		Cars car = new Maruthi();
		car.drive();
		car.playMusic();
		car.transmission();
		
		
	}

}
