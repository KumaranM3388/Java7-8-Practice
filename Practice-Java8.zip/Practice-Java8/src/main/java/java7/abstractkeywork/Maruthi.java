package java7.abstractkeywork;

public class Maruthi extends Cars
{
  public void drive()
  {
	  System.out.println("I know driving !");
  }


  public void transmission() 
  {
	System.out.println("I know drive a manual transmission car !");	
  }
}
