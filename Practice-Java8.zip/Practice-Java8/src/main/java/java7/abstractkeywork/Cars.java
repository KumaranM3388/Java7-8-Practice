package java7.abstractkeywork;

public abstract class Cars 
{
  public abstract void drive();
  
  public abstract void transmission();
  
  public void playMusic()
  {
	  System.out.println("I know how to play a music in the car");
  }
}
