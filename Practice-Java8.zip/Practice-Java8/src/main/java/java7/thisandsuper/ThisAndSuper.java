package java7.thisandsuper;

// this will execute the constructor of same class.

public class ThisAndSuper 
{
 public static void main(String args[])
 {
	 ClassB classB = new ClassB("Kumaran M");
	 //ClassB classB = new ClassB();
 }
}
