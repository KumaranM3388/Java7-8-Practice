package java7.thisandsuper;

public class ClassA 
{
  public ClassA()
  {
	  super();
	  System.out.println("I am Class A");
  }
  
  public ClassA(String s1)
  {
	  super();
	  System.out.println("I am Class A parameterized constructor");
  }
}
