package java7.thisandsuper;

public class ClassB extends ClassA
{
	public ClassB()
	  {
		super();
		System.out.println("I am Class B");
	  }
	
	public ClassB(String s1)
	{
		//super(s1);
		this();
		System.out.println("String in Class B");
	}
}
