package java7.enums;

enum EnumWithConstructor 
{
  Apple(100000), Sony(90000), Asus(75000), Dell(80000), Hp(85000); 
	
	private int price;
	
	private EnumWithConstructor(int price)
	{
		this.price = price;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	
}
