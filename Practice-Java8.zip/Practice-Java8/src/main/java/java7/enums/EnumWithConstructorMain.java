package java7.enums;

public class EnumWithConstructorMain {

	public static void main(String[] args) 
	{
	  EnumWithConstructor withConstructor = EnumWithConstructor.Apple;
	  System.out.println(withConstructor+ " : " +withConstructor.getPrice());
	  
	  for(EnumWithConstructor enm : EnumWithConstructor.values())
	  {
		  System.out.println(enm+ " :: " +enm.getPrice());
	  }
	}

}
