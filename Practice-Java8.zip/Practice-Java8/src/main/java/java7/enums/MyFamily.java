package java7.enums;

enum MyFamily 
{
 Kumaran, Manisha, Samvritha, Jaswin;
}
