package java7.enums;

public class EnumSwitchStatement {

	public static void main(String[] args) {
		
		MyFamily myFamily = MyFamily.Jaswin;
		
		switch (myFamily) 
		{
		case Kumaran:
			System.out.println("1");
			break;
			
		case Manisha:
			System.out.println("2");
			break;
			
		case Samvritha:
			System.out.println("3");
			break;
			
//		case Jaswin:
//			System.out.println("4");
//			break;

		default:
			System.out.println("4");
			break;
		}
		
	}

}
