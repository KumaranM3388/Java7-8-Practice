package java7.enums;

import java7.enums.EnumMethod.Family;

// Enum is a class.
// We con't extend any other class.
// Using enum where we want to use constent values then we can use enum.
// Enum can be easily used in switch.

public class EnumMain
{
	public static void main(String[] args)
	{
	 MyFamily family = MyFamily.Kumaran;
	 System.out.println(family);
	 System.out.println(family.ordinal());
	 
	 MyFamily[] familys = MyFamily.values();
	 for(MyFamily myFam : familys)
		 System.out.println(myFam + " : " + myFam.ordinal());
	 
	 for(Family fam : Family.values())
		 System.out.println(fam+ " : " + fam.ordinal());
	 
	}
}
