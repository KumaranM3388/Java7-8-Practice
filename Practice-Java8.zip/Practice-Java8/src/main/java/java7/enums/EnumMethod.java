package java7.enums;

public class EnumMethod 
{
 public enum Family{Murugan, Chennammal, Santham, Kumaran}
}
