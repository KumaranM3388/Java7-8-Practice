package java7.core;

public class Add {

	public static void main(String[] args)
	{
		int n1 = 15;
		int n2 = 35;
		Calculator cal = new Calculator();
		int finalResult = cal.addition(n1,n2);
		System.out.println(finalResult);
	}

}
