package java7.core;

public class Calculator
{

	public int addition(int i, int j)
	{
	 int res = i + j;
	 return res;
	}
	
}
