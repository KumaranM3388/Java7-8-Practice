package java7.Arrays;

public class Arrays {

	public static void main(String[] args) 
	{
		
		int num[] = {10,21,24,38,9,27};		
		System.out.println(num[3]);
		
		int num1[] = new int[5];
		num1[0] = 7;
		num1[1] = 2;
		num1[2] = 8;
		num1[3] = 14;
		num1[4] = 21;
		System.out.println(num1[3]);
		
		int num2[] = new int[10];
		for(int i=0;i<num2.length;i++)
		{
		System.out.println(num2[i]);
		}
	}

}
