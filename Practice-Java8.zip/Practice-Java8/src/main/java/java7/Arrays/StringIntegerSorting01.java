package java7.Arrays;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StringIntegerSorting01 {

	public static void main(String[] args) {

		Object[] obj1 = {5 , "c", 1 , "g", 7, "f", "a", "e"};
		
		List<Object> strList = Stream.of(obj1).filter(stri -> stri instanceof String)
		.sorted()
		.collect(Collectors.toList());
		
		Collections.addAll(strList, Stream.of(obj1).filter(str -> !(str instanceof String))
	            .sorted().toArray());

	    for (Object o : strList) {
	        System.out.print(o);
	    }		
	}
}
