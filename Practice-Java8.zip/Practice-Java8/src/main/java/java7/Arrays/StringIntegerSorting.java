package java7.Arrays;

import java.util.stream.Stream;

public class StringIntegerSorting {

	public static void main(String[] args) {
		
		Object[] obj1 = {"a", 5 , "c", 1 , "g", 7, "f"};
		Stream.of(obj1).filter(in -> !(in instanceof String))
		.sorted().forEach(System.out::println);
		Stream.of(obj1).filter(in -> in instanceof String)
		.sorted().forEach(System.out::println);
	}

}
