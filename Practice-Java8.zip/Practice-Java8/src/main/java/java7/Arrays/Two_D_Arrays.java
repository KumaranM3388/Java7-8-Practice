package java7.Arrays;

public class Two_D_Arrays {

	public static void main(String[] args) 
	{
	 int num1[][] = new int[2][3];
	 
//	 for(int i=0;i<2;i++)
//	 {
//		 for(int j=0;j<3;j++)
//		 {
//			 System.out.println(num1[i][j]);
//		 }
//	 }
	 
	 // Random Values Generation
	 for(int i=0;i<2;i++)
	 {
		 for(int j=0;j<3;j++)
		 {
			 num1[i][j] = (int) (Math.random() * 100);
			 System.out.println(num1[i][j]);
		 }
	 }
	}

}
