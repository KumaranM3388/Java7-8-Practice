package java7.Arrays;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class ShuffleArray {

	public static void main(String[] args) {
		
		Integer[] intArray = { 1, 2, 3, 4, 5, 6, 7 };
		List<Integer> i1 = Arrays.asList(intArray);
		Collections.shuffle(i1);
		i1.toArray(intArray);
		System.out.println(Arrays.asList(i1));
	 }
	}