package java7.interfaces;

public interface ClassA 
{
  void show();
  void conFig();
}
