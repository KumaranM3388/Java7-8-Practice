package java7.interfaces;

// Class to Class -> Extends
// Class to Interface -> Implements
// Interface to Interface - Extends
// Interface can support - you can have a class implements multiple interfacses.
// If we want to intract one interface to another interface then we can use extends keyword to interact two interfacses.

public class InterfaceMain {

	public static void main(String[] args) 
	{
	  	ClassA obj = new ClassB();
	  	obj.show();
	  	obj.conFig();
	  	
	  	
	  	ClassD obj1 = new ClassB();
	  	obj1.run();
	}

}
