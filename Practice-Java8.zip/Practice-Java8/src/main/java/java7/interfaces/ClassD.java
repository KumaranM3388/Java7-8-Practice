package java7.interfaces;

interface ClassD extends ClassC 
{
 
}
