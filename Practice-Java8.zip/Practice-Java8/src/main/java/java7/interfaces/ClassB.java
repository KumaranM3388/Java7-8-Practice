package java7.interfaces;

public class ClassB implements ClassA,ClassC,ClassD{

	
	public void show() 
	{
		System.out.println("Showing Code !");
	}

	public void conFig() 
	{
		System.out.println("code Config !");
	}

	public void run()
	{
		System.out.println("Code Running !");
	}

}
