package java7.interfaces;

public interface ClassC
{
  void run(); 
}
