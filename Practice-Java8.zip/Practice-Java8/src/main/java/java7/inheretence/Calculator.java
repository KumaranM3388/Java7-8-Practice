package java7.inheretence;

public class Calculator 
{
 public int add(int n1, int n2)
 {
	 return n1 + n2;
 }
 
 public int sub(int n1, int n2)
 {
	 return n1 - n2;
 }
}
