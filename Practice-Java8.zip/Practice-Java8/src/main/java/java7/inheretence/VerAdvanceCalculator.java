package java7.inheretence;

public class VerAdvanceCalculator extends AdvanceCalculator
{
  public double power(int n1, int n2)
  {
	  return Math.pow(n1, n2);
  }
}
