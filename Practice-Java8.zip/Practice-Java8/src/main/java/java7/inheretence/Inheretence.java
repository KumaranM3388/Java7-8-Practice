package java7.inheretence;

public class Inheretence 
{
 public static void main(String args[])
 {
	 //Calculator cal = new Calculator();
	 VerAdvanceCalculator advCal = new VerAdvanceCalculator();
	 int r1 = advCal.add(3, 0);
	 int r2 = advCal.sub(5, 2);
	 int r3 = advCal.multiplication(3, 1);
	 int r4 = advCal.division(9, 3);
	 double r5 = advCal.power(50, 2);
	 System.out.println(r1 + " : " + r2 + " : " + r3 + " : " + r4 + " : " + r5);
 }
}
