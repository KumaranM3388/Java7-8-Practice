package java7.inheretence;

public class AdvanceCalculator extends Calculator
{
	public int multiplication(int n1, int n2)
	 {
		 return n1 * n2;
	 }
	 
	 public int division(int n1, int n2)
	 {
		 return n1 / n2;
	 }
}
