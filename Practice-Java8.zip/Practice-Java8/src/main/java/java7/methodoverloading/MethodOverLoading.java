package java7.methodoverloading;

// Same method name but different parameters is called method overloading.

public class MethodOverLoading {

	public static void main(String[] args) {
		Calculator cal = new Calculator();
		int result = cal.add(5, 10, 15, 20);
		System.out.println(result);
	}

}
