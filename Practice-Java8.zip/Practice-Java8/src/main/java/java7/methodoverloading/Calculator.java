package java7.methodoverloading;

public class Calculator 
{
	public int add(int n1, int n2, int n3)
	{
		return n1+n2+n3;
	}
	
	public int add(int n1, int n2, int n3, int n4)
	{
		return n1+n2+n3+n4;
	}
	
	public int add(int n1, int n2)
	{
		return n1+n2;
	}

}
