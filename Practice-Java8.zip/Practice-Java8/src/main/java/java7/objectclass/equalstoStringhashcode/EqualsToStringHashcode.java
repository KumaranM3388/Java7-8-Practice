package java7.objectclass.equalstoStringhashcode;

public class EqualsToStringHashcode 
{
  public static void main(String args[])
  {
	  Laptop lapTop = new Laptop();
	  lapTop.model = "Apple";
	  lapTop.price = 100000;
	  
	  Laptop lapTop1 = new Laptop();
	  lapTop1.model = "Apple";
	  lapTop1.price = 100000;
	  
	  boolean result = lapTop.equals(lapTop1);
	  System.out.println(result);
  }
}
