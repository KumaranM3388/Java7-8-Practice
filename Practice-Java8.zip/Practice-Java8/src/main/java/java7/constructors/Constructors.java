package java7.constructors;


// It has a same name as a class name.
// Constructor never returns anything.
// Every we create the object then the constructor will call.
// Super() means call the constructor of a super class.

public class Constructors {

	public static void main(String[] args) 
	{
		StudentDetails stdDetails = new StudentDetails();
		System.out.println(stdDetails.getAge() + " : " + stdDetails.getName());
		
		StudentDetails stdDetails1 = new StudentDetails(40, "Rajni");
		System.out.println(stdDetails1.getAge() + " : " + stdDetails1.getName());
	}

}
