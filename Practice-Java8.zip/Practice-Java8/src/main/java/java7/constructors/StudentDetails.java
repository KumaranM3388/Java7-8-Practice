package java7.constructors;

public class StudentDetails
{
  private int age;
  private String name;
  
  public StudentDetails()
  {
//	  this.age = age;
//	  this.name = name;
	  
	  age = 35;
	  name = "Ajith";
  }
  
  public StudentDetails(int a, String n)
  {
	  age = a;
	  name = n;
  }

public int getAge() {
	return age;
}

public void setAge(int age) {
	this.age = age;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}
  
  
}
