package FibonacciSeries;

public class FibonacciSeries {

	public static void main(String[] args) {
		int num1 = 0;
		int num2 = 1;
		int limit = 10;
		int iCount = 0;
		
		// 1st step - Using for-loop
		for(int i=0; i < limit; i++)
		{
			// print Fibonacci series
			System.out.println(num1 + " ");
			
			// get sum for next Fibonacci number
			int sum = num1 + num2;
			num1 = num2;
			num2 = sum;
		}
		
		System.out.println("==================================================");
		
		//2nd step - Using while loop.
//		while(iCount < limit)
//		{
//			// print Fibonacci series
//			System.out.println(num1 + " ");
//			
//			// get sum for next Fibonacci number
//			int sum = num1 + num2;
//			num1 = num2;
//			num2 = sum;
//			iCount++;
//		}
	}

}
