package Interview;

public class ImmutableClassDemo {

	public static void main(String[] args) {
		ImmutableClass i1 = new ImmutableClass("Kumaran", 123);
		String s1 = i1.getName();
		int i2 = i1.getRegNo();
		System.out.println(s1 + " : " + i2);
	}

}
