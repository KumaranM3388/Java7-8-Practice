package Interview;

import java.util.Arrays;

public class StringReplace {

	public static void main(String[] args) {
		String s1 = "kumaran manisha";
		String s2 = s1.replace("r", "a");
		String s3 = s1.replaceAll("a", "r");
		System.out.println(s2);
		System.out.println(s3);
		
	    Arrays.asList(s1.split(" ")).stream().map(c1 -> c1.replaceAll("a", "b")).forEach(obj -> System.out.print(obj));
	}

}
