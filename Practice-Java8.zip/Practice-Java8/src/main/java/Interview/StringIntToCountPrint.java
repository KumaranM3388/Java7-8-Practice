package Interview;

public class StringIntToCountPrint {

	public static void main(String[] args) {
		String s1 = "a2b4c6";
		
		for(int i=0; i<s1.length();i++)
		{
			if(Character.isAlphabetic(s1.charAt(i))) {
				System.out.print(s1.charAt(i));
			} else {
				int x = Character.getNumericValue(s1.charAt(i));
				for(int j=1; j<x;j++)
				{
					System.out.print(s1.charAt(i-1));
				}
			}
		}
	}

}
