package Interview;

import java.util.Random;

public class RandomNumbers {

	public static void main(String[] args) {
		
		Random r1 = new Random();
		System.out.println(r1.nextInt());
	}

}
