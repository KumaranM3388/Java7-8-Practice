package Interview;

public class IntegersInt {

	public static void main(String[] args) {
		Integer i1=100;
		Integer i2=100;		 
		System.out.println(i1==i2);
		 
		Integer i3=150;
		Integer i4=150;		 
		System.out.println(i3==i4);	
		
	}

}
