package Interview;

import java.util.HashMap;
import java.util.Map;

public class MapQus {

	public static void main(String[] args) {
		Map<Integer, Integer> map = new HashMap<>();
		map.put(1,10);
		map.put(2,20);
		Integer output = map.put(1,30);
//		System.out.println(output);
		// Java 7
		for(Map.Entry<Integer, Integer> entry : map.entrySet())
		{
			Integer i1 = entry.getKey();
			Integer i2 = entry.getValue();
			System.out.println("Key :"+ i1 + " Value :" + i2);
		}
		
		// Java 8
		map.forEach((k,v) ->
				{
			      System.out.println("Key: " + k + ", Value: " + v);
				});
		
		}

}
