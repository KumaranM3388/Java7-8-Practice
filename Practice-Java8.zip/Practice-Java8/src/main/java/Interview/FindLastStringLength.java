package Interview;

public class FindLastStringLength {

	public static void main(String[] args) {
		String s1 = "Hello World";
		
		if(s1.length() > 6)
			{
				System.out.println(s1.length());
			}
	}

}
