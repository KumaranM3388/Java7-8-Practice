package Interview;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class FindingCommonElements {

	public static void main(String[] args) 
	{
		List<Integer> list1 = Arrays.asList(1,2,3,4,5);
		List<Integer> list2 = Arrays.asList(3,4,5,6,7);
		
		List<Integer> common = list1.stream().filter(list2::contains).collect(Collectors.toList());
		System.out.println(common);
		
		
		Set<Integer> set1 = new HashSet<>();
        Set<Integer> set2 = new HashSet<>();
        
        for (int i : list1) {
            set1.add(i);
        }
        
        for (int i : list2) {
            set2.add(i);
        }
        
        set1.retainAll(set2);
        System.out.println("Common elements : " + set1);
	}

}
