package Interview;

public class StringQus {

	public static void main(String[] args) {
		String s = "abc";
		s = "xyz";
		System.out.println(s);
		s.concat("test");
		System.out.println(s);
		
		String s1 = "Kumaran";
		String temp ="";
		char ch;
		
		for(int i=0; i<s1.length();i++) {
			ch = s1.charAt(i);
			temp = ch+temp;
		}
		System.out.println(temp);
		
//		String java7= "jaswin";
//        String emptyStr="";
//        char ch;
//
//        for (int i=0; i<java7.length(); i++)
//        {
//            ch= java7.charAt(i); //extracts each character
//            emptyStr= ch+emptyStr; //adds each character in front of the existing string
//        }
//        System.out.println("Reversed word: "+ emptyStr);	
	}

}
