package Interview;

public class Fibonacci {

	public static void main(String[] args) 
	{
	 //int n = 10;
	 int[] n = {1,2,3,4,5,6,7,8,9,10};
	 int num1 = 0, num2 = 1;
	 int count = 0;
	 
	 while(count < n.length)
	 {
		 System.out.print(num1 + " ");
		 int num3 = num2 + num1;
		 num1 = num2;
		 num2 = num3;
		 count = count + 1;
	 }
	}
}
