package Interview;

// Declare the class as final so it can’t be extended.
// Make all of the fields private so that direct access is not allowed.
// Don’t provide setter methods for variables.
// Make all mutable fields final so that a field’s value can be assigned only once.
// Initialize all fields using a constructor method performing deep copy.
// Perform cloning of objects in the getter methods to return a copy rather than returning the actual object reference.

// 1 - Use final keyword
public final class ImmutableClass 
{	
	final String name;
    final int regNo;
    
    // Constructor of immutable class
    // Parameterized constructor
    public ImmutableClass(String name, int regNo)
    {
    	// This keyword refers to current instance itself
    	this.name = name;
    	this.regNo = regNo;
    }

	public String getName() {
		return name;
	}

	public int getRegNo() {
		return regNo;
	}   
    
}

