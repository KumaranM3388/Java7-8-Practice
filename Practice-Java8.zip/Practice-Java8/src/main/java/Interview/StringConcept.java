package Interview;

public class StringConcept {

	public static void main(String[] args) {
		String str = "Java Programming";
		String str1 = "Java Programming";
		
		String str2 = str1;
		if(str.equals(str1))
		{
			System.out.println("Equals Case 1");
		}
		if(str==str1)
		{
			System.out.println("Equals Case 2");
		}
	}

}
