package Interview;

import java.util.HashMap;
import java.util.Map;

public class MapQus1 {

	public static void main(String[] args) 
	{
		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(1,"a");
		map.put(2,"b");
		map.put(3,"c");
		map.put(4,"d");
		
		for(Map.Entry<Integer, String> entry : map.entrySet())
		{
			Integer i1 = entry.getKey();
			String s1 = entry.getValue();
			System.out.println("Key : "+ i1 + " Value :"+ s1);
		}
		map.entrySet().stream()
		//.map(Map.Entry::getValue) - finding value pair.
		.filter(k -> k.getKey()%2 != 0)
		.forEach(obj -> System.out.println(obj));
		
//		try
//		{
//			int i = 0;
//			int j = 0;			
//			j = 5/i;
//			System.out.println("A");
//		} catch (Exception e) {
//			System.out.println("B");
//		} finally {
//			System.out.println("C");
//		}
//		
		
	}

}
