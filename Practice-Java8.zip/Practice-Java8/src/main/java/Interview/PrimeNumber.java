package Interview;

public class PrimeNumber {

	public static void main(String[] args) {
		
		Integer[] lstInt = {2, 3, 4, 6, 11, 8, 9, 5, 7, 10, 12, 15, 18};
		for (int i = 0; i < lstInt.length; i++){
            int temp = 0;
            for (int j = 2; j <= lstInt[i] - 1; j++){
                if (lstInt[i] % j == 0){
                    temp = temp + 1;
                }
            }
            if (temp == 0){
                System.out.println(lstInt[i]+" Prime number");
            }
            else{
                System.out.println(lstInt[i]+" Not Prime Number");
            }
        }
	}

}
