package Interview;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StringUnPairedValues {

	public static void main(String[] args) {
		
		//String s1 = "Hello Kumaran Hello Kumaran";
		
		String s1 = "abbccdeeffghiij";
		List<String> m1 = Arrays.asList(s1.split(""))
				.stream().sorted(Collections.reverseOrder()).distinct().collect(Collectors.toList());
		System.out.println(m1);
		
		System.out.println("---------------------------------------");
				
//		String m2 = Arrays.asList(s1.split(""))
//				.stream().distinct().collect(Collectors.joining(" "));
//		System.out.println(m2);
		
		  int cnt = 0;
		  char[] inp = s1.toCharArray();
		  System.out.println("Duplicate Characters are:");
		  for (int i = 0; i < s1.length(); i++)
		  {
		   for (int j = i + 1; j < s1.length(); j++)
		   {
		    if (inp[i]  == inp[j])
		    {
		     System.out.println(inp[j]);
		     cnt++;
		     break;
		    }
		   }
		  }
		
		
		
		
		
		
	}

}
