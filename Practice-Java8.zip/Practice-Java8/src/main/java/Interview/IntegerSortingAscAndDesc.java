package Interview;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class IntegerSortingAscAndDesc {

	public static void main(String[] args) {
		List<Integer> l1 = Arrays.asList(8,4,7,6,2,1,5,3,4,9);
		
		// Ascending order sorting
		List<Integer> ascending = l1.stream().sorted().collect(Collectors.toList());
		System.out.println("ascending :" + ascending);
		
		System.out.println("--------------------------------");
		
	    // Descending Order Sorting
		List<Integer> descending = l1.stream().sorted(Collections.reverseOrder()).collect(Collectors.toList());
		System.out.println("descending :"+ descending);

	}

}
