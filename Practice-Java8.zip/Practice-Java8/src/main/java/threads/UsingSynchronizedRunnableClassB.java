package threads;

public class UsingSynchronizedRunnableClassB 
{
  int count;
  public synchronized void incrementer()
  {
	  count++;
  }
}
