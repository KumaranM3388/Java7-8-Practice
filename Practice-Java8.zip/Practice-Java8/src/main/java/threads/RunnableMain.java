package threads;

public class RunnableMain {

	public static void main(String[] args) 
	{
	  RunnableClassA runA = new RunnableClassA();
	  RunnableClassB runB = new RunnableClassB();
	  
	  Thread t1 = new Thread(runA);
	  Thread t2 = new Thread(runB);
	  
	  t1.start();
	  t2.start();
	}

}
