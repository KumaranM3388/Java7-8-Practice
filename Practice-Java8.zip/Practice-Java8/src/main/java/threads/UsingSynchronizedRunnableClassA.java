package threads;

public class UsingSynchronizedRunnableClassA 
{
	int count;
	
	  public synchronized void increment()
	  {
		  count++;
	  }
}
