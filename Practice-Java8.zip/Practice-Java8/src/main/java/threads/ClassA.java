package threads;

public class ClassA extends Thread
{
  public void run()
  {
	  for(int i=1;i<=5;i++)
	  {
		System.out.println("Hi i am classA .....");
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	  }
  }

}
