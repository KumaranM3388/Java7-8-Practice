package threads;

public class UsingLambdaRunnableClassMain {

	public static void main(String[] args)
	{
	   Runnable runA = () ->
	   {
		for(int i=1;i<10;i++)
		   {
			   try {
				   System.out.println("Hi i am Runnable runA Using Lambda expression !!!");
				Thread.sleep(200);
			} catch (Exception e) {
				e.printStackTrace();
			}
		   }
	};	
	
	Runnable runB = () ->
	{
			for(int i=1;i<10;i++)
			   {
				   try {
					   System.out.println("Hi i am Runnable runB Using Lambda expression !!!");
					Thread.sleep(200);
				} catch (Exception e) {
					e.printStackTrace();
				}
			   }	
	};
	
	Thread t1 = new Thread(runA);
	Thread t2 = new Thread(runB);
	
	t1.start();
	t2.start();
	}

}
