package threads;

import java.util.Comparator;

public class UsingSynchronizedRunnableMain {

	public static void main(String[] args) throws InterruptedException 
	{
		UsingSynchronizedRunnableClassA syncRunA = new UsingSynchronizedRunnableClassA();
		UsingSynchronizedRunnableClassB syncRunB = new UsingSynchronizedRunnableClassB();
		
		Runnable r1 = () ->
		{
			for(int i=1;i<=50;i++)
			{
				syncRunA.increment();
			}
		};
		
		Runnable r2 = () ->
		{
			for(int i=1;i<=50;i++)
			{
				syncRunA.increment();
				//syncRunB.incrementer();
			}
		};
		
		Thread t1 = new Thread(r1);
		Thread t2 = new Thread(r2);
		t1.start();
		t2.start();
		
		t1.join();
		t2.join();
		System.out.println(syncRunA.count);
		//System.out.println(syncRunB.count);
	}

}
