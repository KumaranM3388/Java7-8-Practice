package threads;

public class ThreadMain {

	public static void main(String[] args) 
	{
	   ClassA clsA = new ClassA();
	   ClassB clsB = new ClassB();
	   
	   clsA.setPriority(Thread.MAX_PRIORITY);
	   clsB.setPriority(Thread.MIN_PRIORITY);
	   
	   clsA.start();
	   clsB.start();
	}

}
