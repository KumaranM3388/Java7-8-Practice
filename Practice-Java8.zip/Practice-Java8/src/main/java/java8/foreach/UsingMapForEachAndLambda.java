package java8.foreach;

import java.util.HashMap;
import java.util.Map;

public class UsingMapForEachAndLambda
{
    public static void main(String[] args) {
        Map<String, Integer> mapVal = new HashMap<>();
        mapVal.put("A", 10);
        mapVal.put("B", 20);
        mapVal.put("C", 30);
        mapVal.put("D", 40);
        mapVal.put("E", 50);
        mapVal.put("F", 60);
        mapVal.forEach((k, v) -> System.out.println("Key : " + k + ", Value : " + v));

        // filter null key and value
        mapVal.put("A", 10);
        mapVal.put("B", 20);
        mapVal.put(null, 30);
        mapVal.put("D", 40);
        mapVal.put("E", null);
        mapVal.put("F", 60);
        if(mapVal != null)
        {
            mapVal.forEach((k, v) -> System.out.println("Lambda Key : " + k + ", Lambda Value : " + v));
        }
    }
}
