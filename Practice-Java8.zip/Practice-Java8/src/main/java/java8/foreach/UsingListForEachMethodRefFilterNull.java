package java8.foreach;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class UsingListForEachMethodRefFilterNull
{
    public static void main(String[] args) {
        List<String> lstStr = new ArrayList<>();
        lstStr.add("A");
        lstStr.add("B");
        lstStr.add("C");
        lstStr.add(null);
        lstStr.add("D");
        lstStr.add("E");
        lstStr.add("F");
        lstStr.forEach(System.out::println);

        // filter null value
        lstStr.stream()
                .filter(Objects::nonNull)
                .forEach(System.out::println);
    }
}
