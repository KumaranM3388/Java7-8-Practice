//package java8.TerminalStreamOperations;
//
//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//import java.util.List;
//import java.util.ArrayList;
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
//class Student {
//    int stuId;
//    String stuName;
//    int stuAge;
//
//
////    Student(int id, int age, String name) {
////        this.stuId = id;
////        this.stuAge = age;
////        this.stuName = name;
////    }
////
////    public int getStuId() {
////        return stuId;
////    }
////
////    public int getStuAge() {
////        return stuAge;
////    }
////
////    public String getStuName() {
////        return stuName;
////    }
//}