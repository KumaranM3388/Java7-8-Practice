package java8.Streams;

import java.util.stream.Stream;


// Stream.empty() creates an empty stream without any values.
// This avoids null pointer exceptions when calling methods with stream parameters.

public class StreamEmpty {

	public static void main(String[] args) 
	{
        Stream<Integer> stream = Stream.empty();
        System.out.println("Size: " + stream.count());
	}

}
