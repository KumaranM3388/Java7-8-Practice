package java8.Streams;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

// Stream.generate() is useful to create infinite values like random integers.
// Stream.generate() returns an infinite sequential unordered stream where the values are generated
// by the provided Supplier.

public class StreamGenerate {

	public static void main(String[] args) 
	{
	 List<UUID> randomIntg = Stream.generate(UUID::randomUUID)
			 .limit(5)
			 .collect(Collectors.toList());
	 
	 randomIntg.forEach(System.out::println);
	}

}
