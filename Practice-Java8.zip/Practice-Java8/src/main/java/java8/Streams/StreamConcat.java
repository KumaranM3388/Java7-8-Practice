package java8.Streams;

import java.util.stream.Stream;

// Stream.concat methods combine two existing streams to produce a new stream.
// The resultant stream will have all the elements of the first stream followed by all the elements of the second stream.

public class StreamConcat {

	public static void main(String[] args) 
	{
		Stream<Integer> stream1 = Stream.of(1, 2, 3);
        Stream<Integer> stream2 = Stream.of(4, 5);

        Stream<Integer> stream3 = Stream.concat(stream1, stream2);

        System.out.println("Elements of concatenated stream");
        stream3.forEach(System.out::println);
	}

}
