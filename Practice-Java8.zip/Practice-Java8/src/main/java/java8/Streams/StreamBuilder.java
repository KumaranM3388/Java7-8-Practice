package java8.Streams;

import java.util.stream.Stream;

// Stream.builder() returns a builder (a design pattern that allows us to construct an object step-by-step) that can be used to add objects to the stream.
// The objects are added to the builder using the add() method.
// Calling build() method on the builder creates an instance of the Stream.

public class StreamBuilder {

	public static void main(String[] args) 
	{
		Stream.Builder<String> builder = Stream.builder();
		builder.add("Kumaran")
        .add("Manisha")
        .add("Samvritha")
        .add("Jaswin");
		
        Stream<String> stream = builder.build();
        stream.forEach(System.out::println);
	}

}
