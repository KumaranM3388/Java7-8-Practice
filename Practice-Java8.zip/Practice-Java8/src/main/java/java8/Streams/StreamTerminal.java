package java8.Streams;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamTerminal {

	public static void main(String[] args)
	{
	List<Integer> i1 = Stream.of(1,2,3,4,5) // Stream source
			.filter(x -> x % 2 != 0) // Intermediate Operation
			.collect(Collectors.toList()); // Terminal Operation
	System.out.println(i1);
	}

}
