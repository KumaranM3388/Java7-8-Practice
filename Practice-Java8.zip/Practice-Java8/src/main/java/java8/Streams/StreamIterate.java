package java8.Streams;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StreamIterate {

	public static void main(String[] args) 
	{
	List<Integer> i1 = Stream.iterate(1, no -> no * 2)
			.limit(10)
						.collect(Collectors.toList());
	System.out.println(i1);
	}

}
