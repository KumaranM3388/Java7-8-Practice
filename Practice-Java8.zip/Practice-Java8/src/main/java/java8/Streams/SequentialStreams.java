package java8.Streams;



public class SequentialStreams {

	public static void main(String[] args) {
		
	}

}
