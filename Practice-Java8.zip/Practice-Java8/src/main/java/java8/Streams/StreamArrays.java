package java8.Streams;

import java.util.Arrays;
import java.util.stream.Stream;

// Arrays.stream() method creates a stream instance from an existing array.
// The resulting stream instance will have all the elements of the array.

public class StreamArrays {

	public static void main(String[] args) 
	{
		Integer[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9};
        Stream<Integer> stream = Arrays.stream(array);
        System.out.println("Size: " + stream.count());
	}

}
