package java8.OptionalClass;

import java.util.Optional;

public class OptionalDemo {

	public static void main(String[] args) {
		
		// Without Using Optional class.
//		String[] s1 = new String[10];
//		String words = s1[5].toLowerCase();
//		System.out.println(words);
		
		// Using Optional class
		String[] s2 = new String[10];
		Optional<String> o1 = Optional.ofNullable(s2[5]);
		if(o1.isPresent())
		{
			String s3 = s2[5].toLowerCase();
			System.out.println(s3);
		} else {
			System.out.println("Value is null !!!");
		}
	}

}
