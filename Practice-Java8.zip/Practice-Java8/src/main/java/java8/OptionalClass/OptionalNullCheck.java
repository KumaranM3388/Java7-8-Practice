package java8.OptionalClass;

import java.util.Optional;

public class OptionalNullCheck {

	public static void main(String[] args) {
		String s1 = null;
		Optional<String> o1 = Optional.of(s1);
		Optional<String> o2 = Optional.of(s1);
		System.out.println(o1);
		System.out.println(o2);
	}

}
