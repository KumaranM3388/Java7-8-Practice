package java8.OptionalClass;


import java.util.Arrays;
import java.util.Optional;

public class OptionalClassEmployee
{
    public static void main(String[] args) {
        Employee emp = new Employee(101,"employee1", null, Arrays.asList("8765432154", "9265409834"));

        // Empty
        Optional<Object> emptyOptional = Optional.empty();
        System.out.println("Checking Empty optional method :" + emptyOptional);

        // Of
        Optional<String> empOptionalEmailId1 = Optional.of(emp.getEmpEmailId());
        System.out.println("Getting Employee Email Id : " + empOptionalEmailId1);
        
        Optional<String> empOptionalEmpPhoneNumber = Optional.of(emp.getEmpPhoneNumbers().toString());
        System.out.println("Getting Employee Phone Number : " + empOptionalEmpPhoneNumber);

        // ofNullable
        Optional<String> empOptionalEmailId2 = Optional.ofNullable(emp.getEmpEmailId());
        System.out.println("Getting Employee Email Id : " + empOptionalEmailId2);
        // If we want to write any default values
        System.out.println(empOptionalEmailId2.orElse("default@gmail.com"));

    }
}
