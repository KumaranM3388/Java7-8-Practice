package java8.SumMultiplicatation;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SummingMainClass
{
    public static void main(String[] args) {
        List<Summing> lstInt = Arrays.asList(new Summing(1,2),
                         new Summing(3,4),
                         new Summing(5,6),
                         new Summing(7,8));
        System.out.println("Original Values --->"+ lstInt);

        List<Summing> finalInt = lstInt.stream()
                .map(cal -> new Summing(cal.X*2,cal.Y*2))
                .collect(Collectors.toList());
        System.out.println("finalInt -------->"+ finalInt);
        
        
        
        List<Integer> sumInt = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        Integer i1 = sumInt.stream().min(Integer::compare).get();
        Integer i2 = sumInt.stream().max(Integer::compare).get();
        System.out.println("Min : "+ i1 + " Max : "+ i2);
        
        Integer i3 = sumInt.stream().mapToInt(Integer::intValue).sum();
        Integer i4 = sumInt.stream().collect(Collectors.summingInt(Integer::intValue));
        System.out.println(i3+" "+i4);
        
        int i5 = sumInt.stream().reduce(0, Integer::sum);
        System.out.println(i5);
    }
}
