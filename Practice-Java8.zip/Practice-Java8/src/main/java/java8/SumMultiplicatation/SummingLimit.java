package java8.SumMultiplicatation;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SummingLimit {

	public static void main(String[] args) 
	{
	 List<Integer> l1 = Arrays.asList(1,2,3,4,5,6,7);
	 //l1.stream().map(1, no -> no * 2).collect(Collectors.toList());
	}

}
