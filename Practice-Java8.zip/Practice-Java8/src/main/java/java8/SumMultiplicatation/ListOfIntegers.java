package java8.SumMultiplicatation;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ListOfIntegers
{
    public static void main(String[] args) {
        List<Integer> lstIntg = Arrays.asList(1,2,3,4,5);
        List<Integer> lstIntItr = lstIntg.stream()
                .map(intg -> intg*intg)
                .collect(Collectors.toList());
        System.out.println("Integers multiplicatation ------------>"+ lstIntItr);
    }
}
