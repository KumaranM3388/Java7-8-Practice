package java8.SumMultiplicatation;

public class Summing
{
    int X,Y;
    Summing(int X, int Y)
    {
        this.X=X;
        this.Y=Y;
    }
    @Override
    public String toString()
    {
        return "(" + this.X + ", " + this.Y + ")";
    }
}
