package java8.MoviesList;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class BeforeJava8Main
{
    public static void main(String[] args) {
        //List<Movie> movieList = new ArrayList<>();

        List<Movie> movieLst = new ArrayList<>();
        movieLst.add(new Movie("Ajith", "Vivegam", "2017"));
        movieLst.add(new Movie("Ajith", "Viswasam", "2019"));
        movieLst.add(new Movie("Ajith", "Valimai", "2022"));
        movieLst.add(new Movie("Ajith", "Thunivu", "2023"));
        movieLst.add(new Movie("Vijay", "Varisu", "2023"));

        findMoviesIn2023usingMap(movieLst);
        findMoviesIn2023usingFlatMap(movieLst);
    }

    // Using Map case
    public static void findMoviesIn2023usingMap(List<Movie> moviesList)
    {
        List<String> findingMovieName = moviesList.stream().filter(year -> year.getReleaseYear().equalsIgnoreCase("2023"))
                .map(name -> name.getMovieName())
                .collect(Collectors.toList());
        System.out.println("Finding Movie Name ---------->"+ findingMovieName);
    }

    // Using FlatMap Case
    public static void findMoviesIn2023usingFlatMap(List<Movie> moviesList)
    {
        moviesList.stream()
                        .filter(year -> year.getReleaseYear() == "2023")
                        .flatMap(name -> Stream.of("Movie Name :"+ name.getMovieName(), "Actor Name :" + name.getActorName()))
                        .collect(Collectors.toList())
                        .forEach(System.out::println);

    }
}
