package java8.MoviesList;


public class Movie
{
    private String actorName;
    private String movieName;
    private String releaseYear;

    public String getActorName() {
        return actorName;
    }

    public void setActorName(String actorName) {
        this.actorName = actorName;
    }

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getReleaseYear() {
        return releaseYear;
    }

    public void setReleaseYear(String releaseYear) {
        this.releaseYear = releaseYear;
    }

    public Movie(String actorName, String movieName, String releaseYear) {
        this.actorName = actorName;
        this.movieName = movieName;
        this.releaseYear = releaseYear;
    }
}
