package java8.Collectors;

public class Employee 
{
  private int empId;
  public String empName;
  private String empGrade;
  private int empSalary;
  
public Employee(int empId, String empName, String empGrade, int empSalary) {
	super();
	this.empId = empId;
	this.empName = empName;
	this.empGrade = empGrade;
	this.empSalary = empSalary;
}

public int getEmpId() {
	return empId;
}

public void setEmpId(int empId) {
	this.empId = empId;
}

public String getEmpName() {
	return empName;
}

public void setEmpName(String empName) {
	this.empName = empName;
}

public String getEmpGrade() {
	return empGrade;
}

public void setEmpGrade(String empGrade) {
	this.empGrade = empGrade;
}

public int getEmpSalary() {
	return empSalary;
}

public void setEmpSalary(int empSalary) {
	this.empSalary = empSalary;
}

@Override
public String toString() {
	return "Employee [empId=" + empId + ", empName=" + empName + ", empGrade=" + empGrade + ", empSalary=" + empSalary
			+ "]";
}


  
  
}
