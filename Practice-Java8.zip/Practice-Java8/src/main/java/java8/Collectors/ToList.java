package java8.Collectors;

public class ToList {

	public static void main(String[] args)
	{
	
	}

}
