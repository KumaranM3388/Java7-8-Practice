package java8.Collectors;

public class ToSet {

	public static void main(String[] args)
	{
	
	}

}
