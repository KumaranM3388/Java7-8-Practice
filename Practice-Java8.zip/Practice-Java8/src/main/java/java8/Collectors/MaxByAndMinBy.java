package java8.Collectors;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

public class MaxByAndMinBy {

	public static void main(String[] args) 
	{
		List<Employee> lst = Arrays.asList(new Employee(1003, "Employee3", "P3", 93000),
				  new Employee(1001, "Employee1", "P1", 51000),
				  new Employee(1004, "Employee4", "P4", 64000),
				  new Employee(1002, "Employee2", "P2", 58000),
				  new Employee(1005, "Employee5", "P5", 101000),
				  new Employee(1006, "Employee5", "P5", 108000));
		
		// Minmum and maximum salary get all employee details.
		Optional<Employee> minBySalary = lst.stream().collect(Collectors.minBy(Comparator.comparingInt(Employee::getEmpSalary)));
		Optional<Employee> maxBySalary = lst.stream().collect(Collectors.maxBy(Comparator.comparingInt(Employee::getEmpSalary)));
		System.out.println(minBySalary + " And Maximum Salary " + maxBySalary);
		
		// Only Minmum and maximum salary.
		// Using method refrence
		int minSalaryMr = lst.stream().map(Employee::getEmpSalary).min(Integer::compare).get();
		int maxSalaryMr = lst.stream().map(Employee::getEmpSalary).max(Integer::compare).get();
		System.out.println("Minimum Salary MR:" +minSalaryMr + " and Maximum Salary: " + maxSalaryMr);
		
		// Only Minmum and maximum salary.
		// Using Lambda expression
		int minSalaryLe = lst.stream().map(sal -> sal.getEmpSalary()).min(Integer::compare).get();
		int maxSalaryLe = lst.stream().map(sal -> sal.getEmpSalary()).max(Integer::compare).get();
		System.out.println("Minimum Salary LM :" +minSalaryLe + " and Maximum Salary: " + maxSalaryLe);
	}

}
