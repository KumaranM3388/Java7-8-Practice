package java8.Collectors;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class GroupingBy {

	public static void main(String[] args) 
	{
	  List<String> lstStr = Arrays.asList("apple","apple","banana","apple","orange","orange","banana","lemon");
	  Map<String, Long> mapCount = lstStr.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	  System.out.println(mapCount);
	  
	  String fruits = "Grapes, Apple, Mango, Banana, Orange, Melons, Apple,Apple,Banana";
      Map<String, Long> mL1 = Arrays.stream(fruits.split("\\,"))
			  .map(tri -> tri.trim())
			  .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
	  System.out.println(mL1);
	  
	  
	  List<Employee> lst = Arrays.asList(new Employee(1003, "Employee3", "P3", 93000),
										  new Employee(1001, "Employee1", "P1", 51000),
										  new Employee(1004, "Employee4", "P4", 64000),
										  new Employee(1002, "Employee2", "P2", 58000),
										  new Employee(1005, "Employee5", "P5", 101000),
										  new Employee(1006, "Employee5", "P5", 108000));
	  
	  Map<String, Long> lstCount = lst.stream().collect(Collectors.groupingBy(Employee::getEmpName, Collectors.counting()));
	  System.out.println(lstCount);	
	  
	  
	 
	}

}
