package java8.Collectors;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SumAndSummingInt {

	public static void main(String[] args) 
	{
		List<Employee> lst = Arrays.asList(new Employee(1003, "Employee3", "P3", 93000),
				  new Employee(1001, "Employee1", "P1", 51000),
				  new Employee(1004, "Employee4", "P4", 64000),
				  new Employee(1002, "Employee2", "P2", 58000),
				  new Employee(1005, "Employee5", "P5", 101000),
				  new Employee(1006, "Employee5", "P5", 108000));
		
		// Using summingInt employee salary
		int summingIntSalary = lst.stream().collect(Collectors.summingInt(Employee::getEmpSalary));
		System.out.println(summingIntSalary);
		
		// Using sum employee salary
		int sumSalary = lst.stream().mapToInt(Employee::getEmpSalary).sum();
		System.out.println(sumSalary);
	}

}
