package java8.Collectors;

public class ToMap {

	public static void main(String[] args) 
	{
	
	}

}
