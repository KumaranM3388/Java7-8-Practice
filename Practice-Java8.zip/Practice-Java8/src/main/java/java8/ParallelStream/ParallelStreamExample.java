package java8.ParallelStream;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class ParallelStreamExample 
{
public static void main(String[] args)
{
	long start = 0;
	long end = 0;
	
	start = System.currentTimeMillis();
	IntStream.range(1, 100).forEach(System.out::println);
	end = System.currentTimeMillis();
	System.out.println("Plain Stream :"+(end-start));
	
	System.out.println("=========================================");
	
	start = System.currentTimeMillis();
	IntStream.range(1, 100).parallel().forEach(System.out::println);
	end = System.currentTimeMillis();
	System.out.println("Parallel Stream :"+(end-start));
	
	List<String> list = Arrays.asList("Hello ", "S!", "G", "E", "K", "E");
	list.parallelStream().forEach(System.out::println);
	
}
}
