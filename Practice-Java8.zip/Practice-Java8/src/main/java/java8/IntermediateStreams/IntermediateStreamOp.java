package java8.IntermediateStreams;

// Streams Intermediate Operations
// filter(predicate),sorted(),distinct(),map().
public class IntermediateStreamOp
{

}
