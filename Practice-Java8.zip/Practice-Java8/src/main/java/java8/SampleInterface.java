package java8;

@FunctionalInterface
public interface SampleInterface {

	void getMessage(String s1);
	
}
