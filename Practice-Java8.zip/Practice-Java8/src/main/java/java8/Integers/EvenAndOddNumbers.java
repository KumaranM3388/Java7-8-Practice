package java8.Integers;

import java.util.Arrays;
import java.util.List;

public class EvenAndOddNumbers
{
    public static void main(String[] args) {
        List<Integer> myList = Arrays.asList(2, 3, 4, 6, 11, 8, 9, 5, 7, 10, 12, 15, 18);
        myList.stream().filter(num -> num%2 != 0).forEach(System.out::println);
        
        System.out.println("--------------------------------------------------");
        
        int[] myList1 = {2, 3, 4, 6, 11, 8, 9, 5, 7, 10, 12, 15, 18};
        Arrays.stream(myList1).filter(num -> num%2 != 0).forEach(System.out::println);
    }
}
