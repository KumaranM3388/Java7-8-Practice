package java8.Integers;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

public class WithOutDuplicates {

	public static void main(String[] args) {
		List<Integer> l1 = new ArrayList<>(Arrays.asList(1, 1, 2, 3, 3, 3, 4, 5, 6, 6, 6, 7, 8));
		
		List<Integer> l2 = l1.stream().distinct().collect(Collectors.toList());
		System.out.println(l2);
		
		Set<Integer> set = new HashSet<>();
		Set<Integer> s1 = l1.stream().filter(num -> !set.add(num)).collect(Collectors.toSet());
		System.out.println(s1);	
		
		Map<Integer, Long> m1 = l1.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(m1);
	}

}
