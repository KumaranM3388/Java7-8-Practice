package java8.Integers;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class ListToInteger {

	public static void main(String[] args) 
	{
	List<String> strList = Arrays.asList("10","5","13","25","75","50");
	List<Integer> listInteger = strList.stream().map(Integer::parseInt).collect(Collectors.toList());
	System.out.println(listInteger);
	}

}
