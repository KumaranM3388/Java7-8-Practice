package java8.Integers;

import java.util.Arrays;
import java.util.List;

public class IntegerStartsWith {

	public static void main(String[] args) {
		List<Integer> l1 = Arrays.asList(5,7,10,21,31,18,25,20,11,41,48);
		l1.stream()
		.map(l -> l + "") // Convert integer to String
		.filter(s -> s.startsWith("2"))
		.forEach(System.out::println);
	}

}
