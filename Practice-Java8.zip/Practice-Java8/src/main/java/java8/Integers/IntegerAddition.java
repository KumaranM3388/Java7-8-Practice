package java8.Integers;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class IntegerAddition {

	public static void main(String[] args) {

		List<Integer> myList = Arrays.asList(10,15,8,49,25,98,30);
		int i1 = myList.stream().collect(Collectors.summingInt(Integer::valueOf));
        System.out.println(i1);
	}

}
