package java8.Integers;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class NumbersStartingWith1
{
    public static void main(String[] args) {
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32);

        // startsWith
        myList.stream().map(num->num+"").filter(num->num.startsWith("1")).forEach(System.out::println);
        // endsWith
        myList.stream().map(num->num+"").filter(num->num.endsWith("5")).forEach(System.out::println);

        List<String> myStr = Arrays.asList("kumaran", "deepan", "kumar", "kumaranmurugan", "raj", "dinesh");
        List<String> s1 = myStr.stream().filter(str -> str.startsWith("kumaran")).collect(Collectors.toList());
        System.out.println(s1);
    }
}
