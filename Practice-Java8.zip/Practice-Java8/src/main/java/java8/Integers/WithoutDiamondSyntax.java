package java8.Integers;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class WithoutDiamondSyntax {

	public static void main(String[] args) {
		List l1 = new ArrayList<>();
		l1.add(100);
		l1.add("101");
		Iterator l2 = l1.iterator();
		while(l2.hasNext())
		{
			System.out.println(l2.next());
		}
	}

}
