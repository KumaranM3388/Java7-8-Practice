package java8.Collections;

import java.util.Iterator;
import java.util.TreeSet;

// Java TreeSet class doesn't allow null element.
// Java TreeSet class is non synchronized.
// Java TreeSet class maintains ascending order.

public class TreeSets {

	public static void main(String[] args) {
		TreeSet<String> treSet = new TreeSet<>();
		treSet.add("A");
		treSet.add("B");
		treSet.add("C");
		treSet.add("D");
		treSet.add("E");
		
		Iterator i1 = treSet.iterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
		
		System.out.println("Traversing element through Iterator in descending order");
		
		Iterator i2 = treSet.descendingIterator();
		while(i2.hasNext())
		{
			System.out.println(i2.next());
		}
	}

}
