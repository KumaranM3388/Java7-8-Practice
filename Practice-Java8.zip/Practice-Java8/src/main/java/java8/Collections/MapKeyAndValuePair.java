package java8.Collections;

import java.util.HashMap;
import java.util.Map;

public class MapKeyAndValuePair {

	public static void main(String[] args)
	{
	   Map<String, Integer> employees = new HashMap<>();
	   employees.put("Santham", 36);
	   employees.put("Kumaran", 34);
	   employees.put("Raja", 34);
	   employees.put("Madhan", 31);
	   
	   //System.out.println(employees);
	   for(String key : employees.keySet())
	   {
		   System.out.println(key + " : "+ employees.get(key));
	   }
	}

}
