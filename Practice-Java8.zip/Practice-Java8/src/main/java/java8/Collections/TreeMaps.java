package java8.Collections;

import java.util.Map;
import java.util.TreeMap;

// TreeMap contains only unique elements.
// TreeMap cannot have a null key but can have multiple null values.
// TreeMap is non synchronized.
//  TreeMap maintains ascending order.

public class TreeMaps {

	public static void main(String[] args) {
		TreeMap<Integer, String> treMap = new TreeMap<>();
		treMap.put(1, "Kumaran");
		treMap.put(2, "Manisha");
		treMap.put(3, "Samvritha");
		treMap.put(4, "Jaswin");
		
		for(Map.Entry m : treMap.entrySet())
		{
			System.out.println(m.getKey()+ " : " + m.getValue());
		}
		
		System.out.println(treMap.descendingMap());
	}

}
