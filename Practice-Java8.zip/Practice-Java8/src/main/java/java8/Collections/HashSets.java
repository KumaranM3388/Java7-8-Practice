package java8.Collections;

import java.util.HashSet;
import java.util.Iterator;

// Hashing is used to store the elements in the HashSet.
// Duplicate values are not allowed.
// HashSet class is non synchronized.
// HashSet is the best approach for search operations.
// HashSet contains unique elements only.
// Objects are inserted based on their hash code.
// NULL elements are allowed in HashSet.

public class HashSets {

	public static void main(String[] args) {
		HashSet<String> h1 = new HashSet<>();
		h1.add("A");
		h1.add("E");
		h1.add("D");
		h1.add("B");
		h1.add("F");
		h1.add("C");
		h1.add("A");
		h1.add("D");
		h1.add(null);
		
		Iterator i1 = h1.iterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
		
	}

}
