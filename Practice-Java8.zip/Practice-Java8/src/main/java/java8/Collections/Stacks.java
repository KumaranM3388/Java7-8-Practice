package java8.Collections;

import java.util.Iterator;
import java.util.Stack;

// It implements the last-in-first-out data structure.

public class Stacks {

	public static void main(String[] args) {
		Stack<String> s1 = new Stack<>();
		s1.push("B");
		s1.push("A");
		s1.push("E");
		s1.push("C");
		s1.push("D");
		s1.pop();
		
		Iterator i1 = s1.iterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
	}

}
