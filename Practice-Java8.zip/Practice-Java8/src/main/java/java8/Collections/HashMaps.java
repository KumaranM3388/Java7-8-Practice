package java8.Collections;

import java.util.HashMap;
import java.util.Map;

// HashMap may have one null key and multiple null values.
// HashMap is non synchronized.
// HashMap maintains no order.
// HashMap contains only unique keys.
public class HashMaps {

	public static void main(String[] args) {
		Map<Integer, String> m1 = new HashMap<>();
		m1.put(1, "A");
		m1.put(2, "C");
		m1.put(3, "E");
		m1.put(4, "D");
		m1.put(5, "B");
		m1.put(1, "F");
		m1.put(null, null);
		
		for(Map.Entry<Integer, String> entry : m1.entrySet())
		{
			System.out.println(entry.getKey() + ":" + entry.getValue());
		}
		
		for(Map.Entry m : m1.entrySet())
		{
			System.out.println(m.getKey()+ " : " + m.getValue());
		}
	}

}
