package java8.Collections;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

// It uses a dynamic array to store the duplicate element of different data types.
// The ArrayList class maintains the insertion order and is non-synchronized.
// ArrayList better for searching.

public class ArrayLists {

	public static void main(String[] args) {
		List<String> l1 = new ArrayList<>();
		l1.add("A");
		l1.add("C");
		l1.add("F");
		l1.add("D");
		l1.add("B");
		
		Iterator i1 = l1.iterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
	}

}
