package java8.Collections;

import java.util.Iterator;
import java.util.LinkedList;

// It uses a doubly linked list internally to store the elements.
// It can store the duplicate elements.
// It maintains the insertion order and is not synchronized.
// In LinkedList, the manipulation is fast because no shifting is required.

public class LinkedLists {

	public static void main(String[] args) {
		LinkedList<String> l1 = new LinkedList<>();
		l1.add("A");
		l1.add("C");
		l1.add("E");
		l1.add("B");
		l1.add("D");
		
		Iterator i1 = l1.iterator();
		while(i1.hasNext())
		{
			System.out.println(i1.next());
		}
	}

}
