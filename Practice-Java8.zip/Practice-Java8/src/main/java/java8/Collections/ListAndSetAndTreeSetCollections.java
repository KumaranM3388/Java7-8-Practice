package java8.Collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class ListAndSetAndTreeSetCollections {

	public static void main(String[] args)
	{
	  
	  System.out.println("---------------------------------ArrayList-------------------------------------");
		
	  // List will produce the result in sorted format.
	  // List will allow duplicate elements.
	  List<Integer> l1 = new ArrayList<Integer>();
	  l1.add(10);
	  l1.add(15);
	  l1.add(20);
	  l1.add(25);
	  l1.add(30);
	  
	  
	  for(int i1 : l1)
	  {
		  //int num = (Integer)i1;
		  System.out.println(i1);
		  //System.out.println(i1*2);
	  }
	  
	  System.out.println("---------------------------------Set-------------------------------------");
	  
	  // Set is collection of unique values.
	  // Set will not produce the result in sorted format.
	  // Set does't allow duplicate elements.
	  Set<Integer> s1 = new HashSet<Integer>();
	  s1.add(10);
	  s1.add(15);
	  s1.add(20);
	  s1.add(25);
	  s1.add(30);
	  
	  
	  for(int i2 : s1)
	  {
		  System.out.println(i2);
		  //System.out.println(i2*2);
	  }
	  
	  System.out.println("---------------------------------TreeSet-------------------------------------");
	  
	      // TreeSet basically Extends AbstractSet 
	      // TreeSet will produce the result in sorted format.
		  // TreeSet does't allow duplicate elements.
		  Set<Integer> t1 = new TreeSet<Integer>();
		  t1.add(10);
		  t1.add(15);
		  t1.add(20);
		  t1.add(25);
		  t1.add(30);
		  t1.add(15);
		  
		  // Step-1
		  for(int i3 : t1)
		  {
			  System.out.println(i3);
			  //System.out.println(i3*2);
		  }
		  
		  // Step-2
//		  Iterator<Integer> i1 = t1.iterator();
//	      while(i1.hasNext())
//	      {
//	    	  System.out.println(i1.next());
//	      }
	}

}
