package java8.Collections;

// ArrayList internally uses a dynamic array to store the elements.
// ArrayList is better for storing and accessing data.
// Better to use ArrayList if searching is more frequent operation than add and remove operation.

// LinkedList internally uses a doubly linked list to store the elements.
// LinkedList is better for manipulating data.
// LinkedList provides constant time for add and remove operations. 
// So it is better to use LinkedList for manipulation.

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class ArrayListsLinkedLists {

	public static void main(String[] args) 
	{
	  List<String> l1 = new ArrayList<>();
	  
	  l1.add("Samvritha");
	  l1.add("Jaswin");
	  l1.add("Kumaran");
	  l1.add("Manisha");
	  
	  
	  
	  for(String s1 : l1)
	  {
		  System.out.println(s1);
	  }
	  
	  System.out.println("=============================");
	  
	  List<String> l2 = new LinkedList<>();
	  
	  l2.add("Samvritha");
	  l2.add("Jaswin");
	  l2.add("Kumaran");
	  l2.add("Manisha");
	  
	  Iterator i1 = l2.iterator();
	  while(i1.hasNext())
	  {
		  System.out.println(i1.next());
	  }
	}

}
