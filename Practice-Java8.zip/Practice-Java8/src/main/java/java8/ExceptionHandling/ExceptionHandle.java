package java8.ExceptionHandling;

public class ExceptionHandle {

	public static void main(String[] args) 
	{
	  int i=0;
	  int j=0;
	  
	  try
	  {
		  j = 2/i;
	  }
	  catch (Exception e)
	  {
		 //e.printStackTrace();
		 System.out.println("Something Went Wrong !!!" + e);
	  } finally {
		System.out.println("Hi i am finally block...");
	}
	  
	  System.out.println("Bye Bye !!!");
	}

}
