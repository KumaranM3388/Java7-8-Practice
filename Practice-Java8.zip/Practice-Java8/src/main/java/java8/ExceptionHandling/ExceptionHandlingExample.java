package java8.ExceptionHandling;

import java.util.Arrays;
import java.util.List;

public class ExceptionHandlingExample {

	public static void main(String[] args) 
	{
		
	  // Step - 1
//	  List<String> l1 = Arrays.asList("10","20","30");
//	  l1.forEach(s1 -> System.out.println(Integer.parseInt(s1)));
	  
	  // Step - 2
	  List<String> l2 = Arrays.asList("10","20","30","xyz");
	  l2.forEach(s1 -> {
		  try
		  {
			  System.out.println(Integer.parseInt(s1));
		  }
		  catch (Exception e) {
			System.out.println("Get the error message :"+ e.getMessage());
		}
	  });
	}

}
