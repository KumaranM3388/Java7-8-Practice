package java8.functionalInterface;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;

// Accept one argument and return no result.
// Single input and returns no output.
// Consumer interface has two methods.
// ACCEPT method -> Is the Single Abstract Method (SAM) which accepts a single argument of type.
// DEFAULT method -> Used for composition.

public class Consumers {

	public static void main(String[] args) {
		List<String> city = new ArrayList<>();
		city.add("Chennai");
		city.add("Bangalore");
		city.add("Mumbai");
		city.add("Delhi");
		city.add("Andhra");
		
		Consumer<String> consum = cities -> System.out.println(cities);
		city.forEach(consum);
		System.out.println("============1=============");
		
		Consumer<Integer> cons1 = c1 -> System.out.println(c1*c1);
		cons1.accept(5);
		cons1.accept(6);
		System.out.println("=============2============");
		
		// Consumer Chaining
		Consumer<Integer> even = c3 -> System.out.println(c3%2==0);
		Consumer<Integer> doubleValue = c4 -> System.out.println(2*c4);
		even.andThen(doubleValue).accept(5);
		doubleValue.andThen(even).accept(6);
		System.out.println("============3=============");
	}

}
