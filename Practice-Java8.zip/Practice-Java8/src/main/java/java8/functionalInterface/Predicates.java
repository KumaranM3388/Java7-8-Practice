package java8.functionalInterface;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

// Accept one argument and return a boolean values.
// Accepts an argument and returns a boolean.
// Predicate Joining - And, Or, negate.

public class Predicates {

	public static void main(String[] args) {
		List<String> city = new ArrayList<>();
		city.add("Chennai");
		city.add("Bangalore");
		city.add("Mumbai");
		city.add("Delhi");
		city.add("Andhra");
		city.add("chennai");
		Predicate<String> filterCity = cities -> cities.equals("Chennai");
		city.stream().filter(filterCity).forEach(System.out::println);
		System.out.println("====================1========================");
		
		Predicate<String> predicat = s -> s.length() > 3;
		System.out.println(predicat.test("Kumaran"));
		System.out.println(predicat.test("Hi"));
		System.out.println("=====================2=======================");
		
		//Predicate Joining
		Predicate<String> p1 = s1 -> s1.length() > 5;
		Predicate<String> p2 = s2 -> s2.length() < 10;
		System.out.println(p1.and(p2).test("Kumaran"));
		System.out.println("=====================3=======================");
		
		System.out.println(p1.or(p2).test("Kumaran"));
		System.out.println("======================4======================");
		
		System.out.println(p1.negate().test("java"));
		System.out.println("======================5======================");
	}

}
