package java8.functionalInterface;

import java.util.Date;
import java.util.function.Supplier;

// It takes no argument and it return some value.
// No input and return objects of supplier type.

public class Suppliers {

	public static void main(String[] args) {
		
		Supplier<Date> currentDate = () -> new Date();
		//Supplier<Date> currentDate = Date::new;
		System.out.println(currentDate.get());
	}

}
