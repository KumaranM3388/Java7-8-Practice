package java8.functionalInterface;

@FunctionalInterface
public interface FunctionalInter 
{
	 void getAbstract(String s1);
	 
	 default void getDefault()
	 {
		 System.out.println("This is default");
	 }
	 
	 static void getStatic()
	 {
		 System.out.println("This is Static");
	 }
}
