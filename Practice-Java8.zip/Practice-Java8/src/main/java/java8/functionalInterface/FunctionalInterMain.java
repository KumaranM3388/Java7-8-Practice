package java8.functionalInterface;

public class FunctionalInterMain implements FunctionalInter{

	@Override
	public void getAbstract(String s1) {
		System.out.println(s1);
	}
	
	public static void main(String[] args) {
		FunctionalInterMain f1 = new FunctionalInterMain();
		f1.getAbstract("Hi i am functional interface !!!");
		FunctionalInter.getStatic();

	}
}
