package java8.functionalInterface;

import java.util.function.Function;

// Accept one argument and it return some value.
// Function -> Apply method.
//1 - Function Chaining -> f1.andThen(f2)
//2 - Compose -> f1.compose(f2)
public class Functions {

	public static void main(String[] args) {
		Function<Integer, Integer> functions = i -> i*i;
		System.out.println(functions.apply(5));
		System.out.println(functions.apply(10));		
		System.out.println("=====================================");
		
		//1 - Function Chaining -> f1.andThen(f2)
		Function<Integer, Integer> addition = i -> i + i;
		Function<Integer, Integer> multiPlication = i -> i*i;
		System.out.println(addition.andThen(multiPlication).apply(5));
		System.out.println(multiPlication.andThen(addition).apply(5));
		System.out.println("=====================================");
		
		//2 - Compose -> f1.compose(f2)
		System.out.println(addition.compose(multiPlication).apply(5));
		System.out.println(multiPlication.compose(addition).apply(5));
		System.out.println("=====================================");
	}

}
