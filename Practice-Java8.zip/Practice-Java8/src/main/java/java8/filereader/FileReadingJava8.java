package java8.filereader;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.stream.Stream;

public class FileReadingJava8
{
    public static void main(String[] args) {
        Path filePath = Paths.get("C:/Users/10702600/Desktop/Content.txt");
        try(BufferedReader bufRead = Files.newBufferedReader(filePath);)
        {
            Stream<String> docRead = bufRead.lines();
            docRead.forEach(System.out::println);

        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
