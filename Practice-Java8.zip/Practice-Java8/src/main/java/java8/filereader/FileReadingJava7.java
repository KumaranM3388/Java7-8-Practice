package java8.filereader;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class FileReadingJava7
{
    public static void main(String[] args) {
        File file = new File("C:/Users/10702600/Desktop/Content.txt");
        try(Reader read = new FileReader(file);)
        {
            // START JAVA 7
            Path path = Paths.get("C:/Users/10702600/Desktop/Content.txt");
            BufferedReader buffRead = Files.newBufferedReader(path);
            String line = buffRead.readLine();
            while (line != null)
            {
                System.out.println(line);
                line = buffRead.readLine();
            }
            // END JAVA 7
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
