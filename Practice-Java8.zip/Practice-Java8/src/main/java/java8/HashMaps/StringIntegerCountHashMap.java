package java8.HashMaps;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class StringIntegerCountHashMap {

	public static void main(String[] args) {
		
		int arr[] = {5,2,7,6,3,9,1,4,5,2,10,8};
		
		Map<Integer, Long> intCount = Arrays.stream(arr).boxed().collect(Collectors.groupingBy(intg -> intg, Collectors.counting()));
		System.out.println("intCount :: " + intCount);
		
		List<String> lstStr = Arrays.asList("apple","apple","banana","apple","orange","orange","banana","lemon");
		Map<String, Long> mapCount = lstStr.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		System.out.println(mapCount);
		
		String fruits = "Grapes, Apple, Mango, Banana, Orange, Melons, Apple,Apple,Banana";
	      Map<String, Long> mL1 = Arrays.stream(fruits.split("\\,"))
				  .map(tri -> tri.trim())
				  .collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
		  System.out.println(mL1);
		
	}

}
