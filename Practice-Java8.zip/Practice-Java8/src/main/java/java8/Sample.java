package java8;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class Sample
{
    public static void main(String[] args) {
    	List<Integer> lstInt = Arrays.asList(1,2,3,4,5,6,7,8,9,10);
        //List<Integer> lstInt = Arrays.asList(3,6,4,7,9,8,98,0,22,55,32,76,12,47,-1, -2);

//        // Adding - Summing
//        Integer usingReduceSum = lstInt.stream().reduce(0, (a, b) -> a + b);
//        System.out.println("Summing Total Integers Values :" +usingReduceSum);
//
//        // Finding Max Values
//        Integer usingReduceMaxValue = lstInt.stream().reduce(0, (a,b) -> a > b ? a : b);
//        System.out.println("Finding Max Values :" +usingReduceMaxValue);
//
//        // Finding Min Values
//        Integer usingReduceMinValue = lstInt.stream().reduce(0, (a,b) -> a < b ? a : b);
//        System.out.println("Finding Min Values :" + usingReduceMinValue);
//
        // Finding longest string
        List<String> longString = Arrays.asList("kumaran", "manisha", "samvritha", "jaswin");
        String findinglongString = longString.stream().reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2).get();
        //System.out.println("Finding longest string :" + findinglongString);
        
       
        String s1 = "efbfekjknjnjhdewdweppPfdenfjkdndaswdwkjfdf";
        Map<String, Long> lstCount = Arrays.asList(s1.split("")).stream().map(x -> x.toUpperCase()).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        //System.out.println(lstCount);
        
        
        String strCount = "hi kumaran how are you";
        int count=0;
      
        for(int i=0; i< strCount.length();i++)
        {
        	if(strCount.charAt(i) != ' ')
        	{
        		count++;
        	}
      	}
        System.out.println(count);
        }
}
