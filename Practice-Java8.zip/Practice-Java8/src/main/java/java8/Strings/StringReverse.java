package java8.Strings;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StringReverse
{
    public static void main(String[] args) {
        String str = "samvritha";
        String reverseString = Stream.of(str.toUpperCase())
                .map(string -> new StringBuilder(string).reverse())
                .collect(Collectors.joining());
        System.out.println("Before Str --------->"+ str+ " After Str ---------->"+reverseString);


        String java7= "jaswin";
        String emptyStr="";
        char ch;

        for (int i=0; i<java7.length(); i++)
        {
            ch= java7.charAt(i); //extracts each character
            emptyStr= ch+emptyStr; //adds each character in front of the existing string
        }
        System.out.println("Reversed word: "+ emptyStr);
    }
}
