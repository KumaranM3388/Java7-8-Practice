package java8.Strings;

public class StringBasics {
    public static void main(String[] args) {
//        String s = "abc";
//        System.out.println(s);
//
//        s = "def";
//        System.out.println(s);
//
//        //String Concatenation
//        String str1 = "Samvritha";
//        String str2 = "Jaswin";
//        //Method 1 : Using concat
//        String str3 = str1.concat(str2);
//        System.out.println(str3);
//        //Method 2 : Using "+" operator
//        String str4 = str1 + str2;
//        System.out.println(str4);


//        int temp, sizeArray = 0;
//        //int arry[] = {3, 7, 9, 3, 5, 5, 0, 1};
//        int arry[] = {10, 20, 25, 63, 96, 57};
//        sizeArray = arry.length;
//
//        for (int i = 0; i < sizeArray; i++) {
//            for (int j = i + 1; j < sizeArray; j++) {
//                if (arry[i] > arry[j]) {
//                    temp = arry[i];
//                    arry[i] = arry[j];
//                    arry[j] = temp;
//                }
//            }
//
//        }
//        System.out.println("Third largest number is:: " + arry[sizeArray - 3]);
        
        
        
        String s1 = new String("abc"); 
        String s2 = new String("abc");
        System.out.println("1-->"+s1.equals(s2)); //true 
        System.out.println("2-->"+(s1 == s2)); //false

        String s3 = "abc";
        String s4 = new String("abc"); 
        System.out.println("3-->"+s3.equals(s4)); //true 
        System.out.println("4-->"+(s3 == s4)); //false

        String s5 = "abc";
        String s6 = s5+"def"; 
        String s7 = "abcdef";
        System.out.println("5-->"+s6.equals(s7)); //true 
        System.out.println("6-->"+(s6 == s7)); //false

        String s8 = "abc"; 
        String s9 = "abc";
        System.out.println("7-->"+s8.equals(s9)); //true 
        System.out.println("8-->"+(s8 == s9)); //true

        String s10 = "abc"; 
        String s11 = "ABC";
        System.out.println("9-->"+s10.equals(s11)); //false 
        System.out.println("10-->"+(s10 == s11)); //false

        String s12 = new String("abc"); 
        String s13 = new String("ABC");
        System.out.println("11-->"+s12.equals(s13)); //false
        System.out.println("12-->"+(s12 == s13)); //false

        String s14 = "abc"; 
        String s15 = "ABC";
        System.out.println("13-->"+s14.equalsIgnoreCase(s15)); //true
        

    	String s = new String("5");
        System.out.println(1 + 10 + s + 1 + 10);
        
        String str = "Java";
        str.concat(" Programming");
        System.out.println(str);
    }
}



