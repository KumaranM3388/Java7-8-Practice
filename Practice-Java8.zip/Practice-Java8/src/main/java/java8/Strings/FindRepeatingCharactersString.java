package java8.Strings;

public class FindRepeatingCharactersString {

	public static void main(String[] args) {
		
		String str = "aabbcddeffgh";
		int n = str.length();
		int freq[] = new int[200];
        char s[] = str.toCharArray();
        for (int i = 0; i < n; i++) {
            if (str.charAt(i) == ' ')  // ignoring the space in the string
                continue;
            else
                freq[(int) str.charAt(i)]++;  // incrementing each character's frequency
        }
        
        for (int i = 0; i < n; i++) {
            if (freq[(int) str.charAt(i)] == 1 && s[i] != ' ') {
                System.out.print(s[i] + " ");
            }
        }
	}

}
