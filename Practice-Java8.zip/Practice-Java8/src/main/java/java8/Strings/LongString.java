package java8.Strings;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class LongString {

	public static void main(String[] args) {
		
		List<String> str = Arrays.asList("kumaran","manisha","samvritha","jaswin");
		
		// Finding Longest String
		String longString = str.stream().reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2).get();
		System.out.println("Longest String : " + longString);		
		System.out.println("**********************************************************");
		
		// String count
        String strLength = "kumaran, manisha, samvritha, jaswin";        
        Map<String, Long> len = Arrays.stream(strLength.split(",")).collect(Collectors.groupingBy(Function.identity(), Collectors.counting()));
        System.out.println("String Length : " + len);
        
        
        int count = 0;
        for(int i=0;i<strLength.length();i++)
        {
        	if(strLength.charAt(i) != ',')
        	{
        		count++;
           	}     	
        }
        System.out.println("Total String Count : "+ count);

	}

}
