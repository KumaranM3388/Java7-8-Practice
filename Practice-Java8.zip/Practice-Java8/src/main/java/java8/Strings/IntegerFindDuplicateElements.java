package java8.Strings;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class IntegerFindDuplicateElements {

	public static void main(String[] args) {
		List<Integer> l1 = Arrays.asList(1,5,7,10,9,3,12,4,20,5,7,11,1);
		
		// Using Set
		Set<Integer> s1 = new HashSet<Integer>();		
		Set<Integer> s2 = l1.stream().filter(dup -> s1.add(dup)).collect(Collectors.toSet());
		System.out.println(s2);
		
		System.out.println("**********************************************");
		
		List<Integer> l2 = l1.stream().distinct().collect(Collectors.toList());
		System.out.println(l2);
		
		Integer min = l1.stream().min(Integer::compareTo).get();
		Integer max = l1.stream().max(Integer::compareTo).get();
		System.out.println(min + " : " + max);
	}

}
