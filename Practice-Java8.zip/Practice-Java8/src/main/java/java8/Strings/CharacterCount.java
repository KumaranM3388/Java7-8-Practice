package java8.Strings;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CharacterCount
{
    public static void main(String[] args) {
        String str = "kumaran hgdwdhf uihgkmgjg iubefefhefh weiufhewiuf";
        int count = 0;
        // Java-8
        Map<String, Long> charCount  = Arrays.asList(str.split(""))
                        .stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        System.out.println("Character Occurence --------->"+ charCount);
        
        // Java-7
        for(int i=0; i<str.length();i++)
        {
        	if(str.charAt(i) != ' ')
        	{
        		count++;
        	}
        }
        System.out.println("Character counts : "+count);
        
        long count1 = Arrays.asList(str.split(" ")).stream().count();
        System.out.println(count1);
    }
}
