package java8.Strings;

public class FindUpperCase {

	public static void main(String[] args) {
		String s1 = "Corejava SpringBoot WebServices Microservice";
		int count = 0;
		
		for(char ch : s1.toCharArray())
		{
			if(Character.isUpperCase(ch))
			{
				count++;
			}
		}
		System.out.println("Upper Case : "+ count);
	}
}
