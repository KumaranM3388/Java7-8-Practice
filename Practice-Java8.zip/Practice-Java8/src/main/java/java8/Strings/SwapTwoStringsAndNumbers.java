package java8.Strings;

public class SwapTwoStringsAndNumbers {

	public static void main(String[] args) {
		String s1 = "Kumaran";
		String s2 = "Manisha";
		
		String temp;
		temp = s1;
		s1 = s2;
		s2 = temp;
		System.out.println("S1 => " + s1);
		System.out.println("S2 => " + s2);
		
		int i1 = 5;
		int i2 = 10;		
		i1 = i1 - i2;
		i2 = i1 + i2;
		i1 = i2 - i1;
		System.out.println("i1 => "+ i1);
		System.out.println("i2 => "+ i2);
	}

}
