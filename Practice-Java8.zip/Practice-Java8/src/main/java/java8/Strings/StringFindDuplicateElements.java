package java8.Strings;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

public class StringFindDuplicateElements {

	public static void main(String[] args) {
		
		String provider[] = {"Amazon", "GCP", "Azure", "Amazon","SauceLabs", "AliBaba", "GCP"};
		
		
		// Java 7
		for(int i = 0; i < provider.length; i++)
		{
			for(int j = i+1; j< provider.length;j++)
			{
				if(provider[i].equals(provider[j]))
				{
					System.out.println(provider[i]);
				}
			}
		}
		
		System.out.println("************************************************");
		
		// Using HashSet
		Set<String> dupli = new HashSet<>();
		for(String str : provider)
		{
			if(dupli.add(str) == false)
			{
				System.out.println(str);
			}
		}
		
		System.out.println("************************************************");
		
		// Using Stream
		Set<String> strSet = new HashSet<String>();		
		Set<String> duplicateSet = Arrays.asList(provider).stream().filter(dup -> !strSet.add(dup)).collect(Collectors.toSet());
		System.out.println(duplicateSet);
		
		System.out.println("************************************************");
	}

}
