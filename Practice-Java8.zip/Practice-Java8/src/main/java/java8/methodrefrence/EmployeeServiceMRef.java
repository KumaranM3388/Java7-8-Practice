package java8.methodrefrence;

import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

public class EmployeeServiceMRef 
{

	public List<EmployeeMRef> empDetails()
	{
		return IntStream.rangeClosed(1, 10)
				.mapToObj(i -> new EmployeeMRef(i, " Employee "+i, new Random().nextInt(500000)))
				.collect(Collectors.toList());
	}
}
