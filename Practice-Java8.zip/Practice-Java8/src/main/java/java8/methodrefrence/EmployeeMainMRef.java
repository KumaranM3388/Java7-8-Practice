package java8.methodrefrence;


public class EmployeeMainMRef {

	public static void main(String[] args) {
		
		EmployeeServiceMRef empSer = new EmployeeServiceMRef();
				
		empSer.empDetails()
		.stream()
		.forEach(System.out::println);
	
	}
}
