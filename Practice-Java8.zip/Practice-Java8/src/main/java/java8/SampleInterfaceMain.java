package java8;

public class SampleInterfaceMain implements SampleInterface {

	@Override
	public void getMessage(String s1) {
		System.out.println(s1);
	}

	public static void main(String[] args) {
		SampleInterfaceMain sample = new SampleInterfaceMain();
		sample.getMessage("Hi i'm functional interface.........");
	}
}
