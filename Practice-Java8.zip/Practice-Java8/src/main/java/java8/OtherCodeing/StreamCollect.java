package java8.OtherCodeing;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamCollect
{
    public static void main(String[] args) {
        List<String> strCollect = Arrays.asList("One", "Two", "Three", "Four", "Five", "Six", "Seven", "One");
        List<String> itrCollect = strCollect.stream()
                .map(val -> val.toUpperCase())
                .distinct()
                .collect(Collectors.toList());
        System.out.println(itrCollect);

        // Finding the Length
        List<Integer> itrLength = strCollect.stream()
                .map(len -> len.length())
                .collect(Collectors.toList());
        System.out.println("String Lengths ---------->"+ itrLength);
    }
}
