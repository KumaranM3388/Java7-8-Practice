package java8.OtherCodeing;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class OddEven
{
    public static void main(String[] args) {
        List<Integer> oddAndEven = Arrays.asList(-2,7,4,0,1,6,34,75,8,12,67,44,56,55);
        List<Integer> result = oddAndEven.stream().filter(obj -> obj%2 == 0).collect(Collectors.toList());
        System.out.println("result ----------->"+ result);
    }
}
