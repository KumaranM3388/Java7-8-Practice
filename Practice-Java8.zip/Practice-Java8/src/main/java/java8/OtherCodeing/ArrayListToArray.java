package java8.OtherCodeing;

import java.util.ArrayList;
import java.util.List;

public class ArrayListToArray
{
    public static void main(String[] args) {
        List<Integer> al = new ArrayList<>();
        al.add(10);
        al.add(20);
        al.add(30);
        al.add(40);

        //Object[] obj = al.toArray();
        for(Integer i : al)
        {
            System.out.println(i+" ");
        }

        // Using Java 8
        int[] arr = al.stream().mapToInt(j8 -> j8).toArray();
        for(int x : arr)
        {
            System.out.println(x+" ");
        }
    }
}
