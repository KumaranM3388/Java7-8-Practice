package java8.OtherCodeing;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamFilter
{
    public static void main(String[] args) {
        List<String> lstStr = Arrays.asList("Java", "Spring", "WebServices", "Microservice", "Mysql");
        List<String> fltrStream = lstStr.stream()
                .filter(str -> ! "Spring".equals(str))
                .collect(Collectors.toList());
        System.out.println(fltrStream);
    }
}
