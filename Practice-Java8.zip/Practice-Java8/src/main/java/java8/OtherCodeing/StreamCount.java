package java8.OtherCodeing;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class StreamCount
{
    public static void main(String[] args) {
        List<String> strCollect = Arrays.asList("One", "Two", "Three", "Four", "Five", "Six", "Seven");
        long  itrCollect = strCollect.stream()
                //.map(val -> val.toUpperCase())
                .filter(len -> len.length() == 4)
                .count();
        //.collect(Collectors.toList());
        System.out.println(itrCollect);

        List<String> result = new ArrayList<>();
        strCollect.stream()
                .filter(specLen -> specLen.length() == 3)
                .map(String::toUpperCase)
                .forEach(result::add);
        System.out.println("result ------->"+ result);
        //.collect(Collectors.toList());
        //System.out.println(partiCount);
    }
}

