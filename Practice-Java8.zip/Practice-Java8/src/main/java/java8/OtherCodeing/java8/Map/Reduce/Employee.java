package java8.OtherCodeing.java8.Map.Reduce;

public class Employee
{
    private int empId;
    private String empName;
    private String EmpGrade;
    private double empSalary;

    public Employee(int empId, String empName, String empGrade, double empSalary) {
        this.empId = empId;
        this.empName = empName;
        EmpGrade = empGrade;
        this.empSalary = empSalary;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpGrade() {
        return EmpGrade;
    }

    public void setEmpGrade(String empGrade) {
        EmpGrade = empGrade;
    }

    public double getEmpSalary() {
        return empSalary;
    }

    public void setEmpSalary(double empSalary) {
        this.empSalary = empSalary;
    }
}
