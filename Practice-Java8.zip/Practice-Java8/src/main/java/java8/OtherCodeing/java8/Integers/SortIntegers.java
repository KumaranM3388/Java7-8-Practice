package java8.OtherCodeing.java8.Integers;

import java.util.Arrays;
import java.util.List;

public class SortIntegers
{
    public static void main(String[] args) {
        List<Integer> myList = Arrays.asList(10,15,8,49,25,-5,98,32);
        myList.stream().sorted().forEach(System.out::println);
    }
}
