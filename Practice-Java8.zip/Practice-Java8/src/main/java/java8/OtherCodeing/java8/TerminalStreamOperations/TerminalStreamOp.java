package java8.OtherCodeing.java8.TerminalStreamOperations;//package java8.TerminalStreamOperations;
//
//// Streams Terminal Operations
////anyMatch(),collect(),count(),findAny(),findFirst(),min() and max(),noneMatch() and allMatch()
//
//import java.util.ArrayList;
//import java.util.List;
//
//public class TerminalStreamOp
//{
//    public static void main(String[] args) {
//        List<Student> lstStud = new ArrayList<>();
//        lstStud.add(new Student(001, "AAAAA",28));
//        lstStud.add(new Student(002, "BBBBB", 27 ));
//        lstStud.add(new Student(003, "CCCCC", 30 ));
//        lstStud.add(new Student(004, "DDDDD", 27 ));
//
//        boolean resultAnyMatch = lstStud.stream().anyMatch(id -> id.getStuName().matches("AAAAA"));
//        System.out.println("Result Any Match ----------->"+ resultAnyMatch);
//
//        boolean resultAllMatch = lstStud.stream().allMatch(id -> id.getStuName().matches("AAAAA"));
//        System.out.println("Result All Match ------>"+ resultAllMatch);
//    }
//}
