package java8.OtherCodeing.java8.IntermediateStreams;

// Streams Intermediate Operations
// filter(predicate),sorted(),distinct(),map().
public class IntermediateStreamOp
{

}
