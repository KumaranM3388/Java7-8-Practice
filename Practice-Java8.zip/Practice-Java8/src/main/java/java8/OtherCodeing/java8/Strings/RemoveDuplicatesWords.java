package java8.OtherCodeing.java8.Strings;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class RemoveDuplicatesWords
{
    public static void main(String[] args) {
        List<String> str = Arrays.asList("A","B","H","T","F","A","I","H");
        List<String> removeRepeated = str.stream()
                .distinct()
                .collect(Collectors.toList());
        System.out.println("Remove Duplicate Words --------->"+ removeRepeated);
    }
}
