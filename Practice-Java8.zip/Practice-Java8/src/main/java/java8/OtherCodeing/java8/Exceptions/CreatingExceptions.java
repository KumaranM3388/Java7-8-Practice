package java8.OtherCodeing.java8.Exceptions;

public class CreatingExceptions
{
    public static void main(String[] args) {
        Exception ex = new Exception();
        System.out.println(ex);
        Exception excMsg = new Exception("Exception Message");
        System.out.println(excMsg);
    }
}
