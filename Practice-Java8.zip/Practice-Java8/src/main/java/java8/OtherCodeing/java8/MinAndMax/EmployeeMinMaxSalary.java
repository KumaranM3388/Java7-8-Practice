package java8.OtherCodeing.java8.MinAndMax;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmployeeMinMaxSalary
{
    public static void main(String[] args) {
        List<EmployeeList> employeeList = new ArrayList<EmployeeList>();
        employeeList.add(new EmployeeList(111, "AAAAA", 32, "Female", "IT", 2011, 25000));
        employeeList.add(new EmployeeList(122, "BBBBB", 25, "Male", "IT", 2015, 13500));
        employeeList.add(new EmployeeList(133, "CCCCC", 29, "Male", "Infrastructure", 2012, 18000));
        employeeList.add(new EmployeeList(144, "DDDDD", 28, "Male", "IT", 2014, 32500));
        employeeList.add(new EmployeeList(155, "EEEEE", 27, "Female", "HR", 2013, 22700));

        // Min And Max Salary
        Optional<EmployeeList> empMaxSalary = employeeList.stream()
                .collect(Collectors.minBy(Comparator.comparingDouble(EmployeeList::getSalary)));
        System.out.println("Employee Max Salary -------->"+ empMaxSalary);

        // Salary filter
        List<EmployeeList> empSalary =  employeeList.stream().filter(sal -> sal.salary > 22500).collect(Collectors.toList());
        System.out.println("empSalary -------->"+ empSalary);

        // Summing Employee Total Salary
        int totalSal = employeeList.stream().collect(Collectors.summingInt(EmployeeList::getSalary));
        System.out.println("Employee Total Salary --------->"+ totalSal);

        // Summing Female Employee Salary
        int totalFemaleEmpSalary = employeeList.stream()
                .filter(sex -> "Female" == sex.getGender())
                .collect(Collectors.summingInt(EmployeeList::getSalary));
        System.out.println("Total Female Employee Salary ------->"+ totalFemaleEmpSalary);

        // Summing Female Employee Salary Count
        long totalFemaleEmpSalaryCount = employeeList.stream()
                .filter(sex -> "Female" == sex.gender)
                .count();
        System.out.println("Female Employee Counts --------->"+ totalFemaleEmpSalaryCount);

        // Based on the filter Start
        List<String> emplNameDetails = employeeList.stream()
                .filter(dept -> "IT" == dept.getDepartment())
                .map(employeeName -> employeeName.getName())
                .collect(Collectors.toList());
        System.out.println("Only emplName --------->"+ emplNameDetails);


        List<Integer> emplOnlySalary = employeeList.stream()
                .filter(dept -> "IT" == dept.getDepartment())
                .map(employeeSalary -> employeeSalary.getSalary())
                .collect(Collectors.toList());
        System.out.println("Only emplSalary --------->"+ emplOnlySalary);
        // Based on the filter End

        // Filter two values using stream and flatmap Start
        employeeList.stream()
                .filter(dept -> dept.getDepartment() =="IT")
                .flatMap(p -> Stream.of("Employee Name :"+p.getName(), "Employee Age :"+ p.getAge()))
                .collect(Collectors.toList())
                .forEach(System.out::println);
        // Filter two values using stream and flatmap End
    }
}
