package java8.OtherCodeing.java8.Default;

public class RunnerImpl
{
    public static void main(String[] args) {
        StudentImpl studImpl = new StudentImpl();
        studImpl.student4();
        Student.student5();
        studImpl.student6();
    }
}
