package java8.OtherCodeing.java8.Collections;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class AddAllList
{
    public static void main(String[] args) {
        List<String> strList = new ArrayList<>();
        strList.add("A");
        strList.add("B");
        strList.add("C");
        strList.add("D");
        strList.add("E");
        strList.add("J");

        LinkedList<String> strLinkedLst = new LinkedList<>();
        strLinkedLst.add("A");
        strLinkedLst.add("F");
        strLinkedLst.add("G");
        strLinkedLst.add("H");
        strLinkedLst.add("I");
        strLinkedLst.add("J");

        strList.addAll(strLinkedLst);
        for(String s1 : strList)
        {
            System.out.println(s1);
        }
    }
}
