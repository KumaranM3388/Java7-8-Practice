package java8.OtherCodeing.java8.SumMultiplicatation;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class SummingMainClass
{
    public static void main(String[] args) {
        List<Summing> lstInt = Arrays.asList(new Summing(1,2),
                         new Summing(3,4),
                         new Summing(5,6),
                         new Summing(7,8));
        System.out.println("Original Values --->"+ lstInt);

        List<Summing> finalInt = lstInt.stream()
                .map(cal -> new Summing(cal.X*2,cal.Y*2))
                .collect(Collectors.toList());
        System.out.println("finalInt -------->"+ finalInt);
    }
}
