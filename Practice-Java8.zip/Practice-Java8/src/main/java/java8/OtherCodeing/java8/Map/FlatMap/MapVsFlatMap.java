package java8.OtherCodeing.java8.Map.FlatMap;

import java.util.List;
import java.util.stream.Collectors;

public class MapVsFlatMap
{
    public static void main(String[] args) {
        List<Customer> lstCust = EmployeeDataBase.getAll();
        List<String> empEmails = lstCust.stream().
                map(email -> email.getEmpEmailId())
                .collect(Collectors.toList());
        System.out.println("Employee Email Id's : "+ empEmails);

        // Stream of Stream data - means data is non flattering structure.
        List<List<String>> empPhoneNousingMap = lstCust.stream()
                .map(phone -> phone.getEmpPhoneNumbers())
                .collect(Collectors.toList());
        System.out.println("Employee Phone Numbers Using Map : "+ empPhoneNousingMap);

        List<String> empPhoneNousingFlatMap = lstCust.stream()
                .flatMap(phone ->phone.getEmpPhoneNumbers().stream())
                .collect(Collectors.toList());
        System.out.println("Employee Phone Numbers Using Flat Map : "+ empPhoneNousingFlatMap);
    }
}
