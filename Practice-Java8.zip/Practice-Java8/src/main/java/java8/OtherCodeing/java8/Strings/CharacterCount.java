package java8.OtherCodeing.java8.Strings;

import java.util.Arrays;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

public class CharacterCount
{
    public static void main(String[] args) {
        String str = "hsddfhdfbiipotioiuytyjjjjjasdadadad";
        Map<String, Long> charCount  = Arrays.asList(str.split(""))
                        .stream().collect(Collectors.groupingBy(Function.identity(),Collectors.counting()));
        System.out.println("Character Occurence --------->"+ charCount);
    }
}
