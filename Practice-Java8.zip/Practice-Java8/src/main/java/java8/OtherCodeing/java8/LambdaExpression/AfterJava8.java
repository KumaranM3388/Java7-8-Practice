package java8.OtherCodeing.java8.LambdaExpression;

import java.util.ArrayList;
import java.util.List;

public class AfterJava8
{
    public static void main(String[] args) {
        List<String> namesLst = new ArrayList<>();
        namesLst.add("User1");
        namesLst.add("User2");
        namesLst.add("User3");
        namesLst.add("User4");
        namesLst.add("User5");

        namesLst.forEach(names -> System.out.println(names));
    }
}
