package java8.OtherCodeing.java8.others;

public class EqualsHashCode
{
    public static void main(String args[])
    {
    String s1 = "Kumaran";
    String s2 = "Kumaran";

    if(s1.equals(s2))
    {
        System.out.println("Equals ----->"+s1.hashCode()+"Hashcode -------->"+s2.hashCode());
    }
    }
}
