package java8.OtherCodeing.java8.Strings;

import java.util.stream.Collectors;
import java.util.stream.Stream;

public class StringReverse
{
    public static void main(String[] args) {
        String str = "Kumaran";
        String reverseString = Stream.of(str.toUpperCase())
                .map(string -> new StringBuilder(string).reverse())
                .collect(Collectors.joining());
        System.out.println("Before Str --------->"+ str+ "After Str ---------->"+reverseString);


        String java7= "Kumaran";
        String emptyStr="";
        char ch;

        for (int i=0; i<java7.length(); i++)
        {
            ch= str.charAt(i); //extracts each character
            emptyStr= ch+emptyStr; //adds each character in front of the existing string
        }
        System.out.println("Reversed word: "+ emptyStr);
    }
}
