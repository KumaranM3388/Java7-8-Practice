package java8.OtherCodeing.java8.Default;

public interface Student
{
    void student1();
    void student2();
    void student3();

    default void student4(){
        System.out.println("I am default method 4.....");
    }

    default void student6(){
        System.out.println("I am default method 6.....");
    }

    static void student5()
    {
        System.out.println("I am static method.....");
    }
}
