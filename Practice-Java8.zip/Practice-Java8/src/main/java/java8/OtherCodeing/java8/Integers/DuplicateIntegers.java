package java8.OtherCodeing.java8.Integers;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DuplicateIntegers
{
    public static void main(String[] args) {
        // Three ways we can find duplicate numbers
        // 1) Filter & Set.add()
        // 2) Map & Collectors.groupingBy
        // collect(Collectors.groupingBy(Function.identity(), Collectors.counting()))
        // 3) Collections.frequency
        // filter(i -> Collections.frequency
        List<Integer> myList = Arrays.asList(10,15,98,8,49,25,98,10,32,17);
        Set<Integer> set = new HashSet<>();
        myList.stream().filter(num -> !set.add(num)).forEach(System.out::println);
    }
}
