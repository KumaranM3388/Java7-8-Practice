package java8.OtherCodeing.java8.Integers;

import java.util.Arrays;
import java.util.List;

public class MaximumInteger
{
    public static void main(String[] args) {
        List<Integer> myList = Arrays.asList(10,15,8,49,25,98,32);
        int maxm = myList.stream().max(Integer::compare).get();
        System.out.println(maxm);
    }
}
