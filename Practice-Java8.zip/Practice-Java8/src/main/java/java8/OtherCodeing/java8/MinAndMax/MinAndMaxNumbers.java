package java8.OtherCodeing.java8.MinAndMax;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;

public class MinAndMaxNumbers
{
    public static void main(String[] args) {
        List<Integer> lstInt = Arrays.asList(3,6,1,8,10,0,-1,4,11);
        // Using CompareTo method
        Integer minNoCompareTo = lstInt.stream().min(Integer::compareTo).get();
        Integer maxNoCompareTo = lstInt.stream().max(Integer::compareTo).get();
        System.out.println("minNo CompareTo------->"+minNoCompareTo+ " maxNo CompareTo-------->"+ maxNoCompareTo);

        // Using Compare method
        Integer minCompare = lstInt.stream().min(Integer::compare).get();
        Integer maxCompare = lstInt.stream().max(Integer::compare).get();
        System.out.println("minNo Compare------->"+minCompare+ " maxNo Compare-------->"+ maxCompare);

        // Using NaturalOrder
        Integer minNaturalOrder = lstInt.stream().min(Comparator.naturalOrder()).get();
        Integer maxNaturalOrder = lstInt.stream().max(Comparator.naturalOrder()).get();
        System.out.println("minNo NaturalOrder------->"+minNaturalOrder+ " maxNo NaturalOrder-------->"+ maxNaturalOrder);
    }
}
