package java8.OtherCodeing.java8.MultipleMap;

import java.util.List;

public class MultipleMapModel
{
    public List<Integer> listA;
    public List<Integer> listB;
    public List<Integer> listC;

    public MultipleMapModel(List<Integer> listA, List<Integer> listB, List<Integer> listC) {
    }

    public List<Integer> getListA() {
        return listA;
    }

    public List<Integer> getListB() {
        return listB;
    }
    public List<Integer> getListC() {
        return listC;
    }
}
