package java8.OtherCodeing.java8.Default;

public class TeacherImpl implements Student {
    @Override
    public void student1() {
        System.out.println("TeacherImpl - 1");
    }

    @Override
    public void student2() {
        System.out.println("TeacherImpl - 2");
    }

    @Override
    public void student3() {
        System.out.println("TeacherImpl - 3");
    }
}
