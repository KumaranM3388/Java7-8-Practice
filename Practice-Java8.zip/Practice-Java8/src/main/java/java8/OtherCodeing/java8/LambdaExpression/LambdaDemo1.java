package java8.OtherCodeing.java8.LambdaExpression;
@FunctionalInterface
public interface LambdaDemo1
{
    void show();
}
