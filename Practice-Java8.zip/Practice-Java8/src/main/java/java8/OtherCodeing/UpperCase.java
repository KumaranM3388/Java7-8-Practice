package java8.OtherCodeing;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class UpperCase
{
    public static void main(String[] args) {
        List<String> lstStr = Arrays.asList("aaa", "bbb", "ccc", "ddd", "eee");
        List<String> lstUpper = lstStr.stream().filter(s->s.length() > 3).map(String::toUpperCase).collect(Collectors.toList());
        lstUpper.forEach(System.out::println);
    }
}
