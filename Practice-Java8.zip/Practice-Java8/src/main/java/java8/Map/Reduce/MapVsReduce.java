package java8.Map.Reduce;



import java.util.Arrays;
import java.util.List;


public class MapVsReduce
{
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(1,2,3,4,5,33,6,7,8,9,10);
        
        System.out.println(numbers.stream().max(Integer::compareTo).get());
        List<String> longestString = Arrays.asList("kumaran","manisha","samvritha","jaswin");

        Integer sum = numbers.stream().mapToInt(add -> add).sum();
        System.out.println("Addition Values : "+ sum);

        Integer reduceSumValues = numbers.stream().reduce(0, (a, b) -> a + b);
        System.out.println("Using Reduce method : "+ reduceSumValues);

        Integer findingMaxValues = numbers.stream().reduce(0, (a, b) -> a > b ? a : b);
        System.out.println("Finding Max Values : "+findingMaxValues);

        Integer findingMaxValuesUsingMethodRef = numbers.stream().reduce(Integer::max).get();
        System.out.println("Finding Max Values Using Method Ref : "+findingMaxValuesUsingMethodRef);

        String longestValue = longestString.stream()
                .reduce((word1, word2) -> word1.length() > word2.length() ? word1 : word2)
                .get();
        System.out.println("Finding Longest Values : " + longestValue);


        // Summing Employee Total Salary First Way
        List<Employee> totalSal = EmployeeDataBase.getAllDetail();
        double addTotal = totalSal.stream().map(sal -> sal.getEmpSalary()).mapToDouble(a->a).sum();
        System.out.println("Employee Total Salary --------->"+ addTotal);


        // Summing Employee Total Salary Second Way
        List<Employee> getAllDetails = EmployeeDataBase.getAllDetail();
        double addingSalary = getAllDetails.stream()
                .filter(grd -> grd.getEmpGrade().equalsIgnoreCase("A"))
                .map(sal -> sal.getEmpSalary())
                .mapToDouble(i -> i)
                .sum();
        // Find Average employee Salary
        // .average().getAsDouble();
        System.out.println("Adding Employee Total Salary : " + addingSalary);

    }
}
