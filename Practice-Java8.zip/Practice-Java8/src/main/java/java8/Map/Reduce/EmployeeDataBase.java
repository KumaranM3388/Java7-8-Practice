package java8.Map.Reduce;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmployeeDataBase
{
        public static List<Employee> getAllDetail()
        {
            return Stream.of(new Employee(101,"Emp1","A",50000.0),
                    new Employee(103,"Emp2","B",60000.0),
                    new Employee(106,"Emp3","A",55000.0),
                    new Employee(102,"Emp4","C",75000.0),
                    new Employee(108,"Emp5","B",65000.0))
                    .collect(Collectors.toList());
        }

}
