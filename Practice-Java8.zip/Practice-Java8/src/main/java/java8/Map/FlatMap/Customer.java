package java8.Map.FlatMap;

import java.util.List;

public class Customer
{
    private int id;
    private String empName;
    private String empEmailId;
    private List<String> empPhoneNumbers;

    public Customer(int id, String empName, String empEmailId, List<String> empPhoneNumbers) {
        this.id = id;
        this.empName = empName;
        this.empEmailId = empEmailId;
        this.empPhoneNumbers = empPhoneNumbers;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getEmpEmailId() {
        return empEmailId;
    }

    public void setEmpEmailId(String empEmailId) {
        this.empEmailId = empEmailId;
    }

    public List<String> getEmpPhoneNumbers() {
        return empPhoneNumbers;
    }

    public void setEmpPhoneNumbers(List<String> empPhoneNumbers) {
        this.empPhoneNumbers = empPhoneNumbers;
    }
}
