package java8.Map.FlatMap;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

// The function you pass to flatmap() operation returns an arbitrary number of values as the output.
// One-to-many mapping occurs in flatMap().
// Perform mapping as well as flattening.
// Produce a stream of stream value.
// flatMap() is used both for transformation and mapping.

public class FlatMapExample {

	public static void main(String[] args) {
		
		List<List<Integer>> number = new ArrayList<>();
	    number.add(Arrays.asList(5, 1));
        number.add(Arrays.asList(8, 4));
        number.add(Arrays.asList(2, 6));
        number.add(Arrays.asList(3, 7));
        
        List<Integer> l1 = number.stream().flatMap(n1 -> n1.stream()).collect(Collectors.toList());
        System.out.println(l1);
	}

}
