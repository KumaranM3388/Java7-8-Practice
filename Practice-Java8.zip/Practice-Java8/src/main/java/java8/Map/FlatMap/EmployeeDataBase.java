package java8.Map.FlatMap;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class EmployeeDataBase
{
    public static List<Customer> getAll(){
        return Stream.of(new Customer(101,"employee1", "emp1@gmail.com", Arrays.asList("8765432154", "9265409834")),
                new Customer(102,"employee2", "emp2@gmail.com", Arrays.asList("6785643255", "9954321100")),
                new Customer(103,"employee3", "emp3@gmail.com", Arrays.asList("8883254338", "7722443355")),
                new Customer(104,"employee4", "emp4@gmail.com", Arrays.asList("9988776655", "8899007788")),
                new Customer(105,"employee5", "emp5@gmail.com", Arrays.asList("8811223344", "9911223344")))
                .collect(Collectors.toList());
    }
}
