package java8.Map.FlatMap;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

// The function passed to map() operation returns a single value for a single input.
// One-to-one mapping occurs in map().
// Only perform the mapping.
// Produce a stream of value.
// map() is used only for transformation.

public class MapExample {

	public static void main(String[] args) {
		ArrayList<String> names = new ArrayList<>();
		names.add("Kumaran");
		names.add("Manisha");
		names.add("Samvritha");
		names.add("Jaswin");
        
        System.out.println("Family Name :" + names);
        
        List lstNames = names.stream().map(l -> l.length()).collect(Collectors.toList());
        System.out.println("Family name length :" + lstNames);
	}

}
