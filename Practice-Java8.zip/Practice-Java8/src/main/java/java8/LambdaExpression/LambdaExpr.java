package java8.LambdaExpression;

@FunctionalInterface
public interface LambdaExpr 
{
   void funInter1(int i);
}
