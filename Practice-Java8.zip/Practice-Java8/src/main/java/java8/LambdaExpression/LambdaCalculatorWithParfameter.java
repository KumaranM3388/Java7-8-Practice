package java8.LambdaExpression;

@FunctionalInterface
public interface LambdaCalculatorWithParfameter 
{
	void getLambCalculatorWithInput(int input);
}
