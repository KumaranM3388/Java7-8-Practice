package java8.LambdaExpression;

@FunctionalInterface
public interface LambdaInterface {

	void LambdaInterfaceOne(int x);
	
	default void LambdaInterfaceTwo()
    {
       System.out.println("Hello default");
    }
	
	static void LambdaInterfaceThree()
	{
		System.out.println("Hello static");
	}
}
