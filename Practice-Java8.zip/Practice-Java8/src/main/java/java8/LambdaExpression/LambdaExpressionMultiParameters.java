package java8.LambdaExpression;

@FunctionalInterface
interface LambdaExpressionMultiParameters 
{
   public int add(int i, int j);
}
