package java8.LambdaExpression;

// Lambda Expression is known as anonymous function(Without name, Without return type and Without access modifier and only having lambda expression (Symbol ->)).
// A lambda expression can have zero or more parameters.
// The arrow token -> separates the parameters from the body of the lambda.


// Static Method
// The static methods in interfaces are similar to default methods but the only difference is that you can’t override them.
// Suppose you want to provide some implementation in your interface and you don’t want this implementation to be overridden in the implementing class. 
// Then you can declare the method as static.

public class LambdaInterfaceMain {

	public static void main(String[] args) {
		
		LambdaInterface l1 = (int x) -> System.out.println(2*x);
		l1.LambdaInterfaceOne(5);
		
		// Static method
		LambdaInterface.LambdaInterfaceThree();
		
		// Default Method
		l1.LambdaInterfaceTwo();
	}

}
