package java8.LambdaExpression;

public class LambdaCalculatorImplWithOutParameter implements LambdaCalculatorWithOutParameter{

	
	@Override
	public void getLambCaluclator() {
      System.out.println("This is first way!!!");	
	}
	
	public static void main(String[] args)
	{
		// Tradational Way start
		LambdaCalculatorImplWithOutParameter lcI1 = new LambdaCalculatorImplWithOutParameter();
		lcI1.getLambCaluclator();
		// Tradational Way End
		
		// Using Lambda Expression without parameter
		LambdaCalculatorWithOutParameter lc1 = () -> {
			System.out.println("Hi i am lambda expression !!! ");
		};
		lc1.getLambCaluclator();
		// Using Lambda Expression without parameter
		
		// Using Lambda Expression with parameter
		
		// Using Lambda Expression with parameter
	}
	
	
	

}
