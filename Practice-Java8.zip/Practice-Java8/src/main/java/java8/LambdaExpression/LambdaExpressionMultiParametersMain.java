package java8.LambdaExpression;

public class LambdaExpressionMultiParametersMain {

	public static void main(String[] args) 
	{
		LambdaExpressionMultiParameters multiParam = new LambdaExpressionMultiParameters() {
			
			public int add(int i, int j) 
			{
				return i + j;
			}
		   };
		int result = multiParam.add(1, 2);
		System.out.println(result);
		
		// Using Lambda Expression.
		LambdaExpressionMultiParameters multiParam1 = (i,j) -> i + j;
		int result1 = multiParam1.add(1, 2);
		System.out.println(result1);
	}

}
