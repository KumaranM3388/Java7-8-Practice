package java8.LambdaExpression;

public class LambdaDemo1Main
{
    public static void main(String[] args) {
        LambdaDemo1 lamd = () -> System.out.println("Hi i am lambda expression");
        lamd.show();
    }
}
