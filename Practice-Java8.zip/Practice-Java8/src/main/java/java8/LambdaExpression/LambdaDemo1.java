package java8.LambdaExpression;
@FunctionalInterface
public interface LambdaDemo1
{
    void show();
}
