package java8.LambdaExpression;

public class LambdaExprMain {

	public static void main(String[] args) 
	{
		LambdaExpr funInt = new LambdaExpr()
		{
	      public void funInter1(int i)
	      {
	    	  System.out.println("Hi !");
	      }
		};
		funInt.funInter1(5);
		
		System.out.println("---------------------------------------------------------------------");
		
		LambdaExpr funIntWithLambda = (int i) ->
		{
			System.out.println("Hi i am using lambda expression here !!"+ i);
		};
		funIntWithLambda.funInter1(10);
	}

}
