package java8.LambdaExpression;

@FunctionalInterface
public interface LambdaCalculatorWithOutParameter 
{
  void getLambCaluclator();  
  
}
