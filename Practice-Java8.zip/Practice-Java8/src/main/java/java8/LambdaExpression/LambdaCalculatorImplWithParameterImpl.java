package java8.LambdaExpression;

public class LambdaCalculatorImplWithParameterImpl{

	
	public static void main(String[] args) {
		LambdaCalculatorWithParfameter lcwP1 = (input) -> {
			System.out.println("Input = " + input);
		};
		lcwP1.getLambCalculatorWithInput(50);
	}

}
