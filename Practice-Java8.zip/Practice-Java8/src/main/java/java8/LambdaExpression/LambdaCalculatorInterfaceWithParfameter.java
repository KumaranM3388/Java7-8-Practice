package java8.LambdaExpression;

@FunctionalInterface
public interface LambdaCalculatorInterfaceWithParfameter 
{
  int addition(int i1, int i2);
}
