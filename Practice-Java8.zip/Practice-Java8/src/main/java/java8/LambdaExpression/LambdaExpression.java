package java8.LambdaExpression;

public class LambdaExpression {

	public static void main(String[] args) {
		
	}

}
