package java8.LambdaExpression;

import java.util.ArrayList;
import java.util.List;

public class BeforeJava8
{
    public static void main(String[] args) {
        List<String> lstStr = new ArrayList<>();
        lstStr.add("User1");
        lstStr.add("User2");
        lstStr.add("User3");
        lstStr.add("User4");
        lstStr.add("User5");

        printLstNames(lstStr);
    }

    public static void printLstNames(List<String> listNames)
    {
        for(int i=0;i<listNames.size();i++)
        {
            System.out.println("Printing Names ---->"+listNames.get(i));
        }
    }
}
