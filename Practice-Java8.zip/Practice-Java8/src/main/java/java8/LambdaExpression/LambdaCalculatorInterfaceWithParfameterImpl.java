package java8.LambdaExpression;

public class LambdaCalculatorInterfaceWithParfameterImpl {

	public static void main(String[] args) {
		
		LambdaCalculatorInterfaceWithParfameter lcIwP1 = (i1, i2) -> {
			return i1-i2;
		};
		
		LambdaCalculatorInterfaceWithParfameter lcIwP2 = (i1, i2) -> {
			if(i1 > i2)
			{
				throw new RuntimeException("Exception Occured!!!");
			}else {
				return i1-i2;
			}
		};
		System.out.println(lcIwP1.addition(10, 100));
		System.out.println(lcIwP2.addition(10, 100));
	}

}
