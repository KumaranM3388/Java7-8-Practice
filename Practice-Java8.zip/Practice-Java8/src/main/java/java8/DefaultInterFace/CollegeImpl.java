package java8.DefaultInterFace;

public class CollegeImpl implements Student{
    @Override
    public void student1() {
        System.out.println("CollegeImpl - 1");
    }

    @Override
    public void student2() {
        System.out.println("CollegeImpl - 2");
    }

    @Override
    public void student3() {
        System.out.println("CollegeImpl - 3");
    }
}
