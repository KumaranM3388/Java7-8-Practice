package java8.DefaultInterFace;

public class StudentImpl implements Student{

    @Override
    public void student1() {
      System.out.println("Student - 1");
    }

    @Override
    public void student2() {
        System.out.println("Student - 2");
    }

    @Override
    public void student3() {
        System.out.println("Student - 3");
    }

}
