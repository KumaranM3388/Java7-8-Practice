package java8.DefaultInterFace;

// Java 8 allows us to add non-abstract methods in the interfaces.
// These methods must be declared default methods.
// Default methods enable us to introduce new functionality to the interfaces of our libraries.
public class RunnerImpl
{
    public static void main(String[] args) {
        StudentImpl studImpl = new StudentImpl();
        studImpl.student4();
        Student.student5();
        studImpl.student6();
    }
}
