package booksNamesort;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class BooksService {

	public List<Books> getBooksSortingOrder()
	{
		List<Books> l1 = new BooksDAO().getBooks();
		Collections.sort(l1, new BooksComparator());
		//Collections.sort(l1, (o1, 02) -> o1.getName().compareTo(o2.getName());
		return l1;
	}
	
	public static void main(String[] args)
	{
		System.out.println(new BooksService().getBooksSortingOrder());
	}
}

class BooksComparator implements Comparator<Books> {

	@Override
	public int compare(Books o1, Books o2) {
		
		// Ascending Order
		//return o1.getName().compareTo(o2.getName());
		
		// Descending Order
		 return o2.getName().compareTo(o1.getName());
	}

}
