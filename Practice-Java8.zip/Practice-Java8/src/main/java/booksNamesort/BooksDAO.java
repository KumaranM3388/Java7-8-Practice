package booksNamesort;

import java.util.ArrayList;
import java.util.List;

public class BooksDAO 
{
	public List<Books> getBooks()
	{
		List<Books> l1 = new ArrayList<>();
		l1.add(new Books(100, "Java", 555));
		l1.add(new Books(88, "SpringBoot", 251));
		l1.add(new Books(114, "WebServices", 301));
		l1.add(new Books(243, "MicroService", 475));
		l1.add(new Books(341, "AWS", 604));
		return l1;
	}
}
